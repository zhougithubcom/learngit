# -*- coding:utf-8 -*-

import os, sys, copy,  base64, hashlib, re, yaml, json
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/../")
import traceback
from  util.http_client import HTTPClient
from urlparse import urlparse


#  x5协议格式发送数据
def  request_in_x5( header, body, url, host=None, proxy=None, client=None ):
    try:
    # 不能变更header和dict的数据
        reqheader = copy.deepcopy(header)
        reqbody = copy.deepcopy(body)
        #  x5中要求body中的数据去除空格
        reqbody = json.dumps(reqbody, separators=(",", ":"), encoding="utf-8", ensure_ascii=False)
        #  规定提供的header中, appid/key作为必要的数据
        appid, appkey = reqheader.get("appid", ""), reqheader.get("key", "")
        sign = hashlib.md5(appid+reqbody+appkey).hexdigest().upper()
        reqheader["sign"] = sign
        
        try: reqheader.pop["key"]
        except: pass
        
        # 实际发送的消息体
        fin_body = {"data": base64.b64encode(json.dumps({"body": reqbody, "header": reqheader}))}
        #  如果存在host, 需要提供请求的header信息
        headers = {}
        if host != None and host.strip() != "":
            rebuild_url = urlparse(url)
            url = url.replace(rebuild_url.netloc, host)
            headers["Host"] = rebuild_url.netloc
        
        # 创建一个httpclient实例, 用来发送请求, 重试次数设定为2
        client = client or HTTPClient(proxy=proxy)
        return client.request_with_retry(url, rtype="POST", headers=headers, body=fin_body, body_type='u', retry_times=1) 
    except:
        return False, "发送请求过程中, 数据处理部分出现异常: %s" %  traceback.format_exc()
    
#  shopapi协议格式发送数据
def  request_in_shopapi( params,  url,  host = None, proxy=None, client=None ):
    try:
        reqparams = copy.deepcopy(params)
        appid, appkey = reqparams.get("appid", ""), reqparams.get("appkey", "")
        try: del reqparams["appid"]
        except: pass
        try: del  reqparams["appkey"]
        except: pass
        
        b64info = base64.b64encode(json.dumps(params, ensure_ascii=False, encoding="utf-8"))
        md5_verify = hashlib.md5("%s%s%s" % (appid, appkey, b64info)).hexdigest()
        fin_params = {"appid": appid, "verify": md5_verify, "params": b64info}
        
        headers = {"Content-Type": "application/json"}
        if host != None and host.strip() != "":
            rebuild_url = urlparse(url)
            url = url.replace(rebuild_url.netloc, host)
            headers["Host"] = rebuild_url.netloc    
        
        client = client or HTTPClient( proxy=proxy )
        return client.request_with_retry(  url, rtype='POST', headers=headers, body=fin_params, body_type="js", retry_times=1 )
    except:
        return False, "发送请求过程中, 数据处理部分出现异常:%s" % traceback.format_exc()
    
#  支付接口协议格式发送数据
def  request_in_payment( params, url,  host=None ):
    try:
        reqparams = copy.deepcopy(params)
        try:del reqparams["key"]
        except: pass
        try: del reqparams["sign"]
        except: pass
        body = ""
        for key in sorted(reqparams.keys()):
            if reqparams[key] != "":
                body += key+"="+str(reqparams[key]) + "&"
        body += "key=%s" % params.get("key", "")
        sign = hashlib.md5(body).hexdigest()
        params["sign"] = sign
        try: del  params["payer_address_state"]
        except: pass
        httpclient = HTTPClient()
        try:  del params["key"]
        except: pass
        headers = {}
        if host != None and host.strip() != "":
            rebuild_url = urlparse(url)
            url = url.replace(rebuild_url.netloc, host)
            headers["Host"] = rebuild_url.netloc
        flag, response = httpclient.request_with_retry(url, rtype='POST', headers=headers,  body=params, body_type="u", retry_times=2)
        if flag:
            if response == "SUCCESS":
                return True, response
            else:
                return False, response
        else: return flag, response
    except:
        return False, "发送请求过程中, 数据处理部分出现异常: %s" % traceback.format_exc()

#  发送body结构为{"data": base64_data}的请求
def  request_in_data_body( b64data, url,  host=None ):
   
    httpclient = HTTPClient()
    headers = {}
    if host != None  and host.strip() != "":
        rebuild_url = urlparse(url)
        url = url.replace(rebuild_url.netloc, host)
        headers["host"]  = rebuild_url.netloc
    return httpclient.request_with_retry(url, rtype='POST', headers=headers, body=b64data, body_type="u", retry_times=1)
   
#  调用加密服务  e:  加密  d: 解密
def  crypt_data(data, ctype='encrypt', ignore=False):
    
    url = yaml.load( open(os.path.dirname(os.path.abspath(__file__)) + "/../config/tools.yaml"  ))["crypt_url"]
    
    etype = { "encrypt": { "method": "encrypt", "data": data },  "decrypt": { "method": "decrypt", "data": data } }.get(ctype)
    if etype == None: return False, "不支持的处理数据方式"
    httpclient = HTTPClient()
    flag, msg = httpclient.request_with_retry( url,  rtype="POST",  body=etype,  body_type='u')
    if  flag : 
        try:
            print msg
            message = json.loads( re.search(r'\"(.*)\"', msg).group(1) )
            if str(message["code"]) != "0":
                if ignore:  return True, data
                else:  return False, msg
            else:
                return True, message["data"]
        except:
            if ignore: return True, data 
            else:  return flag, msg
    else:
        if ignore: return True, data
        else: return False, msg


# -*- coding: utf-8 -*-

import copy, time, os, sys, json

sys.path.append( os.path.dirname(os.path.abspath(__file__)) + "/../")
from util.data import dh

def  tdata_rebuild( tdata ):
    
    rebuild_info = []
    for testset in tdata["testsets"]:
        total_info = { "testtask": tdata["testtask"], "testsets": [] }
        tst_info = { "description": testset["description"], "id": testset["id"], "testset": []}
        
        for testcase in  testset["testset"]:
            tst_info["testset"].append( testcase )
            total_info["testsets"].append( tst_info )
            fin_total_info = copy.deepcopy(total_info)
            rebuild_info.append( fin_total_info )
            total_info["testsets"] = []
            tst_info["testset"] = []
    
    return rebuild_info

''' 处理记录测试数据, 控制执行逻辑'''
class  UtilData(object):
    
    def  __init__( self , **args ):
        
        self.continue_flag = True
        for arg_key, arg_value in args.iteritems():
            if arg_key == "vars":
                if arg_value == []: arg_value = {}
            setattr( self, arg_key, arg_value )
                
        self.result = { "token": "", "testset": "", "testcase": "", "result": "", 
                       "counter": {}, "start_time": "", "execute_time": "", "info": []  }
        self.repeat_result = {}
        self.counter = { "total": 0, "error": 0, "asserts": 0, "passed": 0, "failed": 0, "step-failed": 0 }
        self.info = []
        self.log_data = {}
        self.browser = { }  #  ui需要提供初始化的browser对象，格式定义为[spec_name] = [web object]
        self.http_clients= { }
        
        if "vars" not in args.keys(): self.vars = {}
    
    def  chg_continue_flag(self): self.continue_flag = False
        
    def  clear_vars(self, args):  self.vars = dict( copy.deepcopy( args ) )
            
    def  get_all_properties(self ): return self.__dict__
    
    def  clear_result(self , steps_len=0, token="", testset="", testcase=""):
        
        self.cur_time = time.time()
        self.result = { "token": token , "testset": testset, "testcase": testcase, "result": "", "counter": {}, 
                       "start_time": "%.3f" % (self.cur_time),  "execute_time": 0, "info": [] }
        self.repeat_result = {}
        self.counter = { "total": steps_len, "error": 0, "asserts": 0, "passed": 0, "failed": 0, "step-failed": 0 }
        self.info = []
        self.continue_flag = True
        
    def  update_repeat_results(self, step_id, times, result ):
        self.repeat_result["%s-%s"  %  ( step_id, times )] = { "result": result[0], "info": result[1] }
        
    def  set_result( self, **args ): 
        self.result = dict( self.result, **(args or {}) )
        
    def  fin_summary( self ):
        self.set_result( info=self.info, counter=self.counter )
        if  dh.check_keyvalue_in_list(self.info, "ERROR"):
            self.result["result"] = "ERROR"
        elif  dh.check_keyvalue_in_list(self.info, "FAIL") or dh.check_keyvalue_in_list(self.info, "step-failed"):
            self.result["result"] = "FAIL"
        elif dh.check_keyvalue_in_list( self.info, "SKIPPED" ):
            self.result["result"] = "SKIPPED"
        else:
            self.result["result"] = "PASS"
        self.result["execute_time"] = "%.3f" % ( time.time() - self.cur_time )
        
    def  update_counter(self, flag):
        
        hndl = { None: ["error"], True: ["passed", "asserts"], False: ["failed", "asserts"], "others": ["step-failed"] }
        for  key in hndl[flag]: exec( "self.counter['%s'] += 1" % key )
    
    def  record_info(self, step_id, result, execute_time, utdata, flag=True):
        
        mapper = { True: "PASS", False: "FAIL", None: "ERROR", "SKIPPED": "SKIPPED" }
        if  flag != True:
            self.info.append( {step_id: {"result": mapper[result[0]], "execute_time": "%0.3f" % float(execute_time)}} )
        else:
            message = result[1]
            if type(message) == type({}):
                message = dh.xencode( message )
                message = json.dumps( message )
            self.info.append( {step_id: {"result": mapper[result[0]], "execute_time": "%0.3f" % float(execute_time), "message": str(message)  }} )
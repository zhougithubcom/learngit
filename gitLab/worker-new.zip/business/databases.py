# -*- coding: utf-8 -*-

import os, sys, yaml

file_path = os.path.dirname( os.path.abspath(__file__) ) + "/../"
sys.path.append( file_path )

from util.mysql_client import XmModel

def get_config() :
    return  yaml.load( open( os.path.dirname( os.path.abspath(__file__) ) + "/../" + "config/database.yaml").read() )

class Backend( XmModel ):
    def  __init__( self, country="cn" ):
        self.config = get_config()["backend"][country]
        
class  Front( XmModel ):
    def  __init__( self ):
        self.config = get_config()["front"]

class MitestData( XmModel ):
    def __init__( self ):
        self.config = get_config()["mitest_data"]
        
class PayCallBack( XmModel ):
    def __init__( self ):
        self.config = get_config()["paycallback"]
        
class MitestTools( XmModel ):
    def  __init__( self ):
        self.config = get_config()["mitest_tools"]

class  Pss( XmModel ):
    def  __init__( self ):
        self.config = get_config()["pss"]

class SapBackend( XmModel ):
    def __init__( self ):
        self.config = get_config()["sap_backend"]

class Tmall( XmModel ):
    def __init__( self ):
        self.config = get_config()["tmall"]
        
class  Wms( XmModel ):
    def __init__( self , country="cn"):
        self.config = get_config()["wms"][country]
        
class Xms( XmModel ):
    def __init__( self ):
        self.config = get_config()["xms"]
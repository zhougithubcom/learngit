#-*- coding: utf-8 -*-

import json, os, sys, traceback, time

filepath = os.path.dirname( os.path.abspath(__file__) ) + "/../"
sys.path.append( filepath )

from selenium.common.exceptions import UnexpectedAlertPresentException
from selenium.webdriver.common.alert import Alert

from util.data import dh

def  resultFormat( result, message ):
    
    return json.dumps( { "result": result, "message": message } )

def  action( func ):
    
    def  __decorator( inst, step, utdata ):
        
        try:
            flag, info = func( inst, step, utdata )
        except:
            print traceback.format_exc()
            flag, info = ( None, resultFormat( traceback.format_exc(), "执行过程中出现异常" ) )
        try:
            if flag:
                if step.execute.result != None:
                    for result in step.execute.result or []:
                        key, value = result.items()[0]
                        if value.strip() == "": utdata.vars[key] = info
                        else:
                            if not ( type(info)  == type({}) or type(info) == type([]) ):
                                return False, resultFormat(info, "结果不是一个可以用索引进行访问的格式")
                            rebuild_flag, cvalue = dh.param_rebuild( { "value": value.strip() }, utdata.vars )
                            if not rebuild_flag: return False, resultFormat(info, "无法正常解析结果参数" )
                            
                            actual = dh.get_depth_data( info, cvalue["value"].strip() )
                            if actual[0]:
                                utdata.vars[key] = actual[1]
                            else:
                                return False, resultFormat(info, "新增变量失败， 变量名称: %s , 变量路径: %s" % (key, value) )
        except:
            flag, info = None, resultFormat(info, "步骤分析过程中出现异常: %s" % traceback.format_exc() ) 
        if len( str( info ) ) > 1024*1024:
            return flag, "执行返回结果数据量过大, 提供部分消息: %s" % json.dumps(info)[0:1024*1024]
        return flag, info
    return __decorator


def save_screenshot( token, step, png_data, local=True, url=None ):
    
    if local:
        png_name = "%s_%s_%s.png" % (token, step,  int( time.time() ) )
        
        open( filepath + "ui_automation/screenshots/" + png_name, "a" ).write( png_data )
    
    
    

def  ui_action( func ):
    
    def __decorator( inst, step, utdata ):
        try:
            flag, info = func( inst, step, utdata )
        except UnexpectedAlertPresentException:
            browser = inst.get_browser(step.execute.params, utdata)
            Alert( browser ).accept()
            save_screenshot( utdata.result["token"], step.id, browser.get_screenshot_as_png() )
            return False, "出现未预料的弹层"
        except : 
            flag, info = ( None, resultFormat( traceback.format_exc(),  "执行过程中出现异常" ) )
        try:
            browser = inst.get_browser(step.execute.params, utdata)
            if flag and step.execute.params.get("screenshot") == True: 
                save_screenshot( utdata.result["token"], step.id, browser.get_screenshot_as_png() )
            if not flag:
                save_screenshot( utdata.result["token"], step.id,  browser.get_screenshot_as_png() )
        except: 
            print traceback.format_exc()
        finally:    
            return flag, info
        
    return  __decorator            

        
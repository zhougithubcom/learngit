# -*- coding: utf-8 -*-

import os, sys 
file_path = os.path.dirname( os.path.abspath(__file__) ) + "/../"
sys.path.append( file_path )

from  util.active_model import ActiveModel, ActiveModelSig

class TestTask( ActiveModelSig ): pass

class TestSet( ActiveModel ): pass

class TestCase( ActiveModel ): pass

class TestStep( ActiveModel ): pass

class UtilMapper( ActiveModel ): pass
#-*- coding: utf-8 -*-

import sys, os

file_path = os.path.dirname(os.path.abspath(__file__)) + "/../"
sys.path.append( file_path )
from business import custom_http as ch

def get_goods_stock( stock_flow, sku_list, mihome  ):
    
    pass
    
def  get_goods_stock2( country, sku_id, rep="112", repflag=False, min_size=0, attype="gt"):
    
    print country, sku_id
    mihome = {"112": "0", "112important": "112"}[rep]
    if type(sku_id) != type([]):  products = [sku_id]
    else: products = sku_id
    channel_mapper = {"cn": "cn-order", "tw": "tw", "hk": "hk", "sg": "sg", "my": "my", "presales": "pre-sales" }
    if type(mihome) != type([]): mihome = [mihome for _ in products] 
    print country, products, mihome
    body = {"channel": channel_mapper[country], "goods_id": products, "mihome_id": mihome}
    header = {"appid": "xm_1000", "key": "620d6feadc997a6f194aee377ea868b8"}
#     sign = X5_create_sign(header, body)
    url = "http://10.237.36.185:8015/api/querystock"
#     situ, tsitu, data, _ = self.hb.http_handler(url, htype="POST", body=sign, expect_return="json")
     
    print ch.request_in_x5(header, body, url)
    
get_goods_stock2("cn", [1111,1023,1314], "112")
#     if not situ or not tsitu: return False
#     if data.get("header", {}).get("code", "") != 200: return False
#     stock_msg = data.get("body")
#     if stock_msg == None: return False
#     stock = stock_msg[0]["sale_stock"]
#     if attype == "gt":
#         if stock > int(min_size): return True
#         else: return False
#     elif attype=="lt":
#         if stock < int(min_size): return True
#         else: return False      
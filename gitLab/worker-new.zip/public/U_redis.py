#-*- coding: utf-8 -*-

import os, sys, json, redis
from phpserialize import serialize, unserialize, loads, phpobject
import traceback

file_path = os.path.dirname( os.path.abspath(__file__) ) + "/../"
sys.path.append( file_path )

from business.decorator import action
from util.data import dh
from util import phpserialize_impv

class UtilRedis( object ):
    
    def  rd_handler( self, step, utdata ):
        
        flag, params = dh.param_rebuild( step.execute.params, utdata.vars )
        if not flag: return None, params
        
        connect_config = dh.del_key_from_dict( getattr(utdata, params["connection"]), "type" )
        if connect_config.get("port") != None:
            connect_config["port"] = int( connect_config["port"] )
        else:
            return None, "端口号不能转化为整型"
        return redis.StrictRedis(**connect_config), params
        
    def  info_hndler( self, info ):
        
        try: 
            info = json.loads( info, encoding="utf-8")
        except:
            try: 
                try:
                    info = unserialize(info)
                except ValueError:
                    try: 
                        info = loads( info, object_hook=phpobject)._asdict()
                    except:
                        info = phpserialize_impv.loads( info.replace("O:8\"stdClass\"", "a"), object_hook=phpobject )
                if isinstance( info, dict): info = dh.xencode(info)
            except:
                pass
        return info
    
    def  multi_unserialize(self, info):
        
        new_info = {}
        try: 
            for k, v in info.iteritems():
                try: 
                    try: new_info[k] = unserialize(v)
                    except ValueError: 
                        new_info[k] = unserialize(v,  object_hook=phpobject )._asdict()
                except:
                    try: new_info[k] = json.loads(v)
                    except: new_info[k] = v
        except:  pass
        return new_info
    
    @action
    def  get(self , step, utdata ):
        
        con, params = self.rd_handler(step, utdata)
        if not con: return con, params
        keyword = params.get("keyword")
        if not keyword:
            return False, "为提供关键字keyword"
        else:
            return True, self.info_hndler(keyword)
        
    @action
    def  hget( self, step, utdata ):
        
        con,params = self.rd_handler(step, utdata)
        if not con: return con, params
        if "hash_name" in params.keys() and "keyword" in params.keys():
            info = con.hget( params["hash_name"], params["keyword"] )
            return True, self.info_hndler( info ) 
        else:
            return None, "缺失关键字 hash_name / keyword"
        
    @action
    def  set( self, step, utdata ):
        
        con, params = self.rd_handler(step, utdata)
        if not con: return None , params
        
        essential_keywords = ["keyword", "value", "serialize"]
        flag, paths = dh.check_key_in_map(params, **essential_keywords)
        if not flag: return None, paths
        
        value = params["value"]
        if params["serialize"]: value= serialize( value )
        
        info = con.set( params["keyword"], value )
        return True, info
    
    @action
    def  hgetall( self, step, utdata ):
        
        con, params = self.rd_handler(step, utdata)
        if not con: return None, params
        
        if "keyword" not in params.keys():
            return None, "缺失关键字段keyword"
        else:
            info = con.hgetall(params["keyword"])
            return True, self.multi_unserialize(self.info_hndler(info))
        
    
    @action
    def hset(self, step, utdata):
        
        con, params = self.rd_handler(step, utdata)
        essential_keywords = ["hash_name", "keyword", "value", "serialize"]
        flag, paths = dh.check_key_in_map(params, *essential_keywords)
        if not flag: return None, paths
        value = params["value"]
        if params["serialize"]: value =serialize(value)
        info = con.hset( params["hash_name"], params["keyword"], value)
        return True, info
    
    
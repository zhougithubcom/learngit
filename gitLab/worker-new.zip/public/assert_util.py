#-*- coding: utf-8 -*-

import os, sys, re, json
from errno import EPERM

if os.path.dirname(os.path.abspath(__file__)) + "/../" not in sys.path: sys.path.append( os.path.dirname(os.path.abspath(__file__)) + "/../" )

from  business.decorator import action
from util.data import dh

class UtilAssert( object ):
    
    def  init_params( self, step, utdata ):
        
        flag, params = dh.param_rebuild( step.execute.params, utdata.vars )
        if not flag: return None, params
        
        rflag, paths = dh.check_key_in_map( params, *["expect", "actual"] )
        if not rflag: return None, "步骤缺失必要参数, 参数路径为: %s" % paths
        
        return params["actual"], params["expect"]

    def compare_template( self, sym, step, utdata, ty='float' ):
        
        actual, expect = self.init_params(step, utdata)
        if actual == None: return actual, expect
        if eval( "%s(actual) %s %s(expect)" % ( ty, sym, ty ) ): return True, "实际结果: %s, 期望结果: %s" % (actual, expect)
        else: return False, "实际结果: %s, 期望结果: %s" % (actual, expect)
    
    @action
    def equal(self, step, utdata): return self.compare_template( "==", step, utdata, "str" )
    
    @action
    def  lt(self, step, utdata): return self.compare_template("<", step, utdata)
    
    @action 
    def gt(self, step, utdata): return self.compare_template(">", step, utdata)
    
    @action
    def le( self, step, utdata ): return self.compare_template("<=", step, utdata)
    
    @action
    def ge( self, step, utdata ): return self.compare_template(">=", step, utdata)
    
    @action
    def  notequal(self, step, utdata): return self.compare_template("!=", step, utdata, "str")
    
    @action
    def  match( self, step, utdata ):
        actual, expect = self.init_params(step, utdata)
        if actual==None: return actual, expect
        if re.match( expect, actual ) != None: return True, "实际结果: %s, 期望结果: %s" % (actual, expect)
        else: return False, "实际结果: %s, 期望结果: %s, 不能正则匹配" % (actual, expect)
    
    @action
    def  isList( self, step, utdata ):
        aflag, alist = dh.param_rebuild( step.execute.params, utdata.vars )
        if not aflag: return None, alist
        try: actual = eval( alist.get("list") )
        except: return False, "非数组格式"
        if isinstance( actual, list): return True, "为数组格式"
        else: return False, "非数组格式"
        
    @action
    def  listElementCount( self , step, utdata ):
        
        flag, alist = dh.param_rebuild(step.execute.params, utdata.vars )
        if not flag: return None, alist
        count = list.get("count")
        try: klist = eval( alist.get("list") )
        except: return None, "提供的list不能解析为list格式"
        
        if isinstance(count, int) or isinstance(klist, list):
            return None, "提供的count或list字段值不符合测试要求"
        else:
            for el in klist:
                if isinstance(el, list) and isinstance(el, map): return None, "list非[[],[]],[{},{}]格式"
                if len(el) != count: 
                    return False, "list中某些元素的长度与提供的count不一致"
            return  True, "长度一致"
        
    @action
    def  listElementEqual( self, step, utdata ):
        
        flag, alist = dh.param_rebuild( step.execute.params, utdata.vars )
        if not flag: return flag, alist
        try:
            expect = eval(alist.get("expect"))
            klist = eval(alist.get("list"))
        except:
            return None, "输入的expect或list格式不正确，无法正常解析"
        if isinstance(klist, list):
            return None, "输入的list不是数组格式"
        else:
            if list(set(list(klist))) == [expect]: return True, "元素一致"
            else: return False, "某些数据信息不一致, list: %s, count: %s" % ( json.dumps(klist), json.dumps(expect) )
    
    @action
    def  listEqual(self, step, utdata):
        
        flag, alist = dh.param_rebuild(step.execute.params, utdata.vars)
        if not flag: return None, alist
        try:
            expect = eval( alist.get("expect") )
            actual = eval( alist.get("actual") )
        except:
            return None, "非数组格式, list为: %s" % str(alist)
        
        if  not isinstance(expect, list) or not isinstance(actual, list) : return None, "expect或actual字段不是数组格式, expect: %s, actual: %s" % ( json.dumps(expect), json.dumps(actual) )   
        else:
            if len(expect) != len(actual): return False, "期望结果与实际结果长度不一致, expect: %s, actual: %s" % ( json.dumps(expect), json.dumps(actual) )
            else:
                for ep in expect:
                    if ep not in actual : return False, "expect中的%s元素不在actual中"  % ep
                for ac in actual:
                    if ac not in expect: return False, "actual中的%s元素不在expect中" % ac
                return True, "expect与actual相等"
    
    @action
    def  listContain( self, step, utdata ):
        
        flag, alist = dh.param_rebuild(step.execute.params, utdata.vars )
        if not flag: return None, alist
        
        flag = True
        unmatched_data = []
        try:
            small = eval( alist.get("small") )
            large = eval( alist.get("large") )
        except: return False, "expect 或 actual 字段不是数组格式, small: %s, large: %s" % ( str(alist.get("small")), str(alist.get("large")) )
        
        if not isinstance( small, list) or not isinstance( large, list ):
            return False, "expect或actual字段不是数组格式, small: %s, large: %s" % ( json.dumps(small), json.dumps(large) )
        else:
            for sm in small:
                if sm not in large:
                    unmatched_data.append(sm)
                    flag = False
            if flag: return True, "参数small传递的变量在large中"
            else:
                return False, unmatched_data
            
    @action
    def  listElementBetween(self, step, utdata):
        
        flag, alist = dh.param_rebuild( step.execute.params, utdata.vars )
        if not flag: return None, alist
        try: cmax, cmin, elist = float( alist.get("max") ), float( alist.get("min") ), eval( alist.get("list") )  
        except: return None, "传递的参数格式不正确，max/min必须为浮点型(整型), list必须为表达式类型"
        
        if cmax < cmin: return None, "max不应该比min小"
        if isinstance( elist, list ): return None, "list传递的值不是数组格式"
        else:
            try: nll = [ float(el) for el in elist ]
            except: return False, "list元素只能为整数或整数形式的字符"
            for nl in nll:
                if  nl<cmin or nl>cmax: return False, "list中元素超出了限定范围"
            return True, "list的每个元素都在min和max之间"

    @action
    def  listIn( self, step, utdata ):
        
        flag, alist = dh.param_rebuild( step.execute.params, utdata.vars )
        if not flag: return None, alist
        try: 
            element = eval( alist.get("element") )
            llist = eval( alist.get("list") )
        except:
            return None, "传递的参数格式不正确，应该为数组格式"
        
        if  not isinstance( llist, list ): return None, "list应该为数组格式"
        
        if element not in llist: return False, "element:%s 不是list: %s的子元素" % ( json.dumps(element), json.dumps(llist) )
        else: return True, "子元素关系匹配"
        
    @action
    def  listNotIn( self, step, utdata ):
        
        flag, alist = dh.param_rebuild( step.execute.params, utdata.vars )
        if not flag: return None, alist
        try: 
            element = eval( alist.get("element") )
            llist = eval( alist.get("list") )
        except:
            return None, "传递的参数格式不正确，应该为数组格式"
        
        if  not isinstance( llist, list ): return None, "list应该为数组格式"
        
        if element  in llist: return False, "element:%s 不是list: %s的子元素" % ( json.dumps(element), json.dumps(llist) )
        else: return True, "子元素关系匹配"
            
    @action
    def  listCount( self, step, utdata ): 
        
        flag, alist = dh.param_rebuild(step.execute.params,  utdata.vars)
        if not flag: return flag, alist
        
        try:
            count = int( alist.get("count") )
            llist = int( alist.get("list") )
        except:
            return None, "传递的参数格式不正确， count应为整数，list为数组"
        
        if not isinstance( llist, list ): return None, "list应该为数组格式"
           
        else:
            if   len(llist) != count: return False, "list：%s长度为%d, 期望的长度为%s" %  (str(llist), len(llist), str(count))
            return True, "list长度与期望的长度一致"        
        
    
    @action
    def  infoCompare( self , step, utdata ): 
        
        flag, alist = dh.param_rebuild(step.execute.params, utdata.vars )
        if not flag: return flag, alist   
        
        try:
            info = eval( alist.get("info") )
            cmp_info = eval( alist.get("cmp_info") )
            scope = alist.get( "keys" )
            str_ignore = alist.get( "ignore_types" )
        except:
            return None, "传递的参数格式不正确"
        
        flag = True
        err_msg = []
        if scope == None:
            if info == cmp_info: return True, "相同"
            else: return False, "不相同"
        
        for pth in scope.split(","):
            pth = pth.strip
            o1, v1 = dh.get_depth_data( info, cmp_info )
            o2, v2 = dh.get_depth_data( info, cmp_info )
            if not o1: 
                flag = False
                err_msg.append( "在%s中，不存在路径%s信息" % (pth, json.dumps(info)  ) )
                continue                
            if not o2:
                flag = False
                err_msg.append( "在%s中, 不存在路径%s的信息" % (pth, json.dumps(info)) )
                continue
            
            if str_ignore:
                if str(v1) != str(v2):
                    flag = False
                    err_msg.append("路径: %s结果不一致, info中的结果: %s， cmp中的结果为: %s" % ( pth, str(v1), str(v2)))
            else:
                if v1 != v2:
                    flag = False
                    err_msg.append("路径: %s结果不一致, info中的结果: %s， cmp中的结果为: %s" % ( pth, str(v1), str(v2)))
                    
        return flag, "\n".join(err_msg)
    
    @action
    def multiCmp(self, step, utdata):
        
        flag, actual = dh.param_rebuild( step.execute.params, utdata.vars )
        if not flag: return flag, actual
        
        try: actual = eval( actual.get("actual") )
        except: return None, "actual格式不正确"
        
        flag, params = dh.param_rebuild( step.execute.params.get("params"), utdata.vars )
        if not flag: return None, "params格式不正确"
        
        flag, err_msg = True, []
        
        for key, value in params.iteritems():
            plag, pvalue = dh.get_depth_data( actual, key )
            if not plag:
                flag = False
                err_msg.append("路径: %s在变量中actual不存在" % key)
                continue
            elif str(pvalue) != str(value):
                flag = False
                err_msg.append("路径：%s对应的actual值为：%s与期望值: %s不一致" %(key, str(pvalue), str(value)))
        return flag, "\n".join(err_msg)
    
        
        
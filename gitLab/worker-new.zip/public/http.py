#-*- coding: utf-8 -*-

import os, sys, uuid, json
sys.path.append( os.path.dirname(os.path.abspath(__file__)) + "/../" )

from business import custom_http as cuh
from util.http_client import HTTPClient
from business.decorator import action
from util.data import dh 
import urllib

class  HTTPUtil( object ):
    
    @action
    def  init_client_with_cookie( self, step, utdata ):
        
        try:
            uniq_data = str( uuid.uuid4() )
            utdata.http_clients[uniq_data] = HTTPClient( cookie_type='A' )
            return True, uniq_data
        except:
            return False, "生成HTTP客户端失败"
    
    def  get_http_client( self , step, utdata ):

        flag, params = dh.param_rebuild(step.execute.params, utdata.vars)
        if not flag:
            return None, "解析参数过程出现异常"
        else:
            http_label = params.get("client")
            
            if not http_label:
                return True, HTTPClient( cookie_type='F')
            else:
                if utdata.http_clients.get( http_label ) == None:
                    return False, None
                else:
                    return True, utdata.http_clients.get(http_label)
        
    @action    
    def  request( self, step , utdata ):
        
        flag, client = self.get_http_client(step, utdata)
        if not flag:
            return flag, client
        
        flag, params = dh.param_rebuild( step.execute.params, utdata.vars )
        if not flag:
            return None, "解析参数过程出现异常"
        # 检测关键字段是否存在
        flag, paths = dh.check_key_in_map( params, *["url", "type" ] )
        if not flag:
            return None, "测试步骤缺失必要关键字: %s" % paths
        
        body = params.get("body", "")
        
        if params.get("body_type", "r") != "r" and  params.get("type") == "POST":
            try: 
                body = json.loads(body)
            except: 
                try: body = eval(body)
                except: pass
                if isinstance(body, dict): pass
                else: return None, "传递的body格式与body_type希望的处理方式不一致"
                
        return client.request_with_retry( params["url"], rtype=params["type"], headers=params.get("headers"), body=body  , retry_times=1, body_type=params.get("body_type", "r")  )
    
    @action        
    def  x5_request( self, step, utdata ):
        
        flag, client = self.get_http_client(step, utdata)
        if not flag: 
            return flag, client
        
        flag, params = dh.param_rebuild( step.execute.params, utdata.vars)
        if not flag:
            return None, "解析参数过程出现异常"
        
        flag, paths = dh.check_key_in_map( params, "header", "body", "url" )
        if not flag:
            return None, "缺失必要参数, %s" % paths
        
        return cuh.request_in_x5( params["header"], params["body"], params["url"], host=params.get("host"), client=client )
    
    @action
    def  shopapi_request( self, step, utdata ):
        
        flag, client = self.get_http_client(step, utdata)
        if not flag: 
            return flag, client
        
        flag, params = dh.param_rebuild( step.execute.params, utdata.vars)
        if not flag:
            return None, "解析参数过程出现异常"
        
        flag, paths = dh.check_key_in_map( params, "params", "url"  )
        if not flag: 
            return None, "缺失必要参数: %s" % paths
        
        return cuh.request_in_shopapi(params["params"], params["url"], params.get("host", client=client) )
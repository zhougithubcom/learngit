#-*- coding: utf-8 -*-


import os, sys

if os.path.dirname(os.path.abspath(__file__)) + "/../" not in sys.path:
    sys.path.append( os.path.dirname(os.path.abspath(__file__)) + "/../" )

from util.data import dh
from business.decorator import action
from util.mysql_client import XmModel

class UtilMysql( object ):
    
    def template(self, step, utdata, method ):
        
        params = step.execute.params
        connection = dh.del_key_from_dict(  getattr(utdata, params["connection"]), "type" )
        conn_flag, conn_paths = dh.check_key_in_map( connection, *["db", "host", "passwd", "port", "user"] )
        if not conn_flag: return conn_flag,  "连接缺失必要的字段信息: %s" % conn_paths
        
        try: connection["port"] = int( connection["port"] )
        except: return conn_flag, "提供的端口号不能转换为整型"
        
        xm = XmModel()
        xm.config = connection
        
        trn_flag, trn_data = dh.param_rebuild( params,  utdata.vars )
        if not trn_flag: 
            return False, "转化参数过程中出现异常，异常信息为: %s" % trn_data
        
        return getattr(xm, method )( trn_data.get("sql", ""), retry_times = 1 ) 
    
    @action
    def  hfind( self, step, utdata ):
        
        return self.template( step, utdata, "find_one")
    
    @action
    def  hfindall( self, step, utdata ):
        
        return self.template( step, utdata, "find_all" )     
   
    @action
    def  update( self, step, utdata ): 
        
        return self.template( step, utdata, "update" )   
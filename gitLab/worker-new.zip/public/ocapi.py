#-*- coding: utf-8 -*-

import os, sys

sys.path.append( os.path.dirname(os.path.abspath(__file__)) + "/../" )
from business.custom_http import request_in_x5
from business.decorator import action
from util.data import dh


class OcAPI( object ):
    
    def  __init__(self , basic_info = {}):
        
        self.basic_info = basic_info
    
    @action
    def  request(self, step, utdata):
        
        if (step.execute.params or {}).get("connection") == None:
            return None, "测试步骤缺失关键字段connection, 无法执行操作"
        
        try:
            basic_params = dh.del_key_from_dict( getattr(utdata, step.execute.params["connection"]), "type" )
        except :
            return None, "数据处理过程出现异常"
        
        flag, datas = dh.check_key_in_map(basic_params, *[ "appid", "appkey", "user_id", "user_name", "url" ] )
        if not flag:
            return None, "配置信息中缺失必要参数, 请检查是否填写过程中填写了错误的关联connection。配置信息为: %s, 缺失的参数为: %s" % ( step.execute.params["connection"], datas )
        
        url, host = basic_params["url"], basic_params.get("host", "") 
            
        header = {}
        for key, value in  { "appid": "appid", "key": "appkey", "user_id": "user_id", "user_name": "user_name" }:
            header[key] = basic_params[value]
        if url[-1] != "/": url = url + "/"
        
        basic_params = dh.del_key_from_dict( basic_params, "appid", "appkey", "user_id", "user_name" )
        api = step.execute.params["api"]
        
        body = step.execute.params.get("params", {})
        new_body = dh.cp_dict(body)
        
        trn_flag, body = dh.param_rebuild( body, utdata.vars )
        if not trn_flag:
            return None, "初始化body异常, 没有获取到某些参数值。初始信息为: %s" % new_body

        return request_in_x5( header, body, url+api, host=host )
        
        
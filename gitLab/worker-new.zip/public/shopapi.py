#-*- coding: utf-8 -*-

import os, sys, json

sys.path.append( os.path.dirname(os.path.abspath(__file__)) + "/../" )
from business.custom_http import request_in_shopapi
from business.decorator import action
from util.data import dh


class ShopAPI( object ):

    @action    
    def  request( self, step, utdata ):
        
        flag, paths = dh.check_key_in_map(step.execute.params, *[ "api","connection" ] )
        if not flag:  return None, "测试步骤缺失关键字: %s" % paths
        
        try:  basic_params = dh.del_key_from_dict( getattr(utdata, step.execute.params["connection"]), "type"  )
        except: return None, "无法获取名称为%s的shopapi配置信息, 请检查是否关联了错误的connection"  % ( step.execute.params["connection"])
            
        if  getattr( utdata, step.execute.params["connection"] ).get("type") != "shopapi":
            return None, "选择的connection类型不是shopapi类型, 请检查数据有效性"
        
        flag, paths = dh.check_key_in_map( basic_params, *["appid", "appkey", "url"]  )
        if not flag: return None, "配置信息中缺失必要字段，配置信息名称为:%s, 缺失的关键字为: %s" %  ( step.execute.params["connection"] , paths )
        
        url, host = basic_params["url"], basic_params.get("host", "")
        basic_params = dh.del_key_from_dict( basic_params, "url", "host" )
        if url[-1] != "/": url = url+"/"
        api = step.execute.params["api"]
        params = dh.comb_dict(  basic_params, dh.del_key_from_dict(step.execute.params["params"], "connection", "api") or {} )
        flag, params = dh.param_rebuild( params, utdata.vars )
        if not flag: return None, "初始化参数过程中异常， 某些变量信息没有找到。错误信息为: %s"  % params
        
        flag, msg = request_in_shopapi( params, url+api, host=host )
        if not flag: return flag, msg
        else:
            try:  return flag, json.loads( msg )
            except: return flag, msg
# -*- coding: utf-8 -*-

import os, sys, urllib2, yaml, json, traceback

file_path = os.path.dirname( os.path.abspath(__file__) ) + "/../"

sys.path.append( file_path )
from  run.run_util import run


if __name__ == "__main__":
    
    token, env = sys.argv[1], sys.argv[2]
    config = yaml.load(  open( file_path + "config/basic.yaml" ).read() )
    fataler_url = config["fataler"] % env
    debug_url = config["debuger"] % env
    tdata = ""
    
    try:
        tdata = json.loads( urllib2.urlopen( debug_url ).read() )
    except:
        urllib2.urlopen( fataler_url, json.dumps({"token": token, "crashed_of": "无法获取调试信息" }) )
        sys.exit()
    
    if tdata.get("success"):
        urllib2.urlopen( fataler_url, json.dumps({"token": token, "crashed_of": "服务端提供了错误的信息, 具体内容为: %s" % json.dumps(tdata) }), encoding='utf-8' )   
        sys.exit()
    
    try:
        run( tdata["testtask"], tdata["testsets"], env )
    except:
        urllib2.urlopen( fataler_url, json.dumps({"token": token, "crashed_of": traceback.format_exc() }) )
    
    
# -*- coding: utf-8 -*-

import sys, os, pickle, urllib2, traceback, json, yaml

filepath =  os.path.dirname( os.path.abspath(__file__) ) + "/../"
sys.path.append( filepath )

from run.run_util import run

try:
    
    data = pickle.loads( sys.argv[1] ) 
    
    env = sys.argv[2]
    
    run( data["testtask"], data["testsets"], env )
    
except:
    
    if __name__ == "__main__":
        
        data = pickle.loads( sys.argv[1] )
        env = sys.argv[2]
        try:
            fatal_url = yaml.load( open(filepath+"/config/basic.yaml").read() )["fataler"] % env
            token = data["testset"]["token"]
            urllib2.urlopen( fatal_url, json.dumps( { "token": token, "crashed_of": traceback.format_exc() } ) )
        except:
            pass
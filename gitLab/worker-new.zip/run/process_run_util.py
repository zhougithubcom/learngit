#-*- encoding:utf-8 -*-

import os, sys, urllib2, json, subprocess, psutil, pickle, time, yaml

reload(sys)
sys.setdefaultencoding("utf-8")

import traceback
file_path = os.path.dirname( os.path.abspath(__file__) ) + "/../"
sys.path.append( file_path )
from kazoo.client import KazooClient
from util.system.zookeeper import create_node
from util.system.system import get_machine_ip
from business.data import tdata_rebuild

if __name__ == "__main__":
    
    multi_runner_path = os.path.dirname( os.path.abspath(__file__) ) + "/multi_runner.py"


    config = yaml.load( open(file_path+"config/basic.yaml").read() )
    kazoo_server = config["zookeeper"]
    processors = config["processors"]
    
    client = KazooClient( kazoo_server )
    client.start()
    
    busy_path = ""
    
    if len(sys.argv) > 2:
        try: 
            token = sys.argv[1]
            env = sys.argv[2]
            
            fatal_url = config["fataler"] % env
            start_url = config["starter"] % env  + token + "/pull"
            feedback_url = config["worker"] % env
            client_pid_path = file_path + "config/pid/%s_client_pid.pid" % token

            busy_path = "/mitest/%s/busy/%s/%s" % ( env, get_machine_ip(), token )
            client_pid = str( os.getpid() )
            open( client_pid_path, "w" , 0 ).write( client_pid + "\n" + token )
            
            create_node( client, busy_path, True )

            tdata = json.loads( urllib2.urlopen( start_url ).read() )
            if tdata.get("success") == False:
                urllib2.urlopen( fatal_url, json.dumps({"token": token, "crashed_of": "服务端提供了错误的信息，具体内容为: %s \n" % json.dumps(tdata)}), encoding='utf-8' )
                sys.exit()
            
            rebuild_total_info = tdata_rebuild( tdata )
            total_case_length = len( rebuild_total_info )
            
            if total_case_length < processors:
                ava_process = total_case_length
            else:
                ava_processes = processors
                
            del_list = []
            for idx in xrange( ava_process ):
                subprocess.Popen( ["python", multi_runner_path, pickle.dumps(rebuild_total_info[idx]),  env ] )
                del_list.append( rebuild_total_info[idx] )
            for idx in range( ava_process ):
                rebuild_total_info.remove( del_list[idx] )
            counter = 3
            while True:
                if len( rebuild_total_info ) == 0:
                    while True:
                        if len( [chd.status() for chd in psutil.Process( os.getpid()).get_children() if chd.status() != "zombie"] ) == 0: break
                        else: time.sleep(1)
                    break
                
                cur_running = len( [chd.status() for chd in psutil.Process(os.getpid()).get_children() if chd.status() != "zombie"  ] )
                if cur_running == ava_process: continue
                
                free_processes = processors - cur_running
                
                if free_processes > len(rebuild_total_info):    
                    new_ava_processes = len( rebuild_total_info )
                else:
                    new_ava_processes = free_processes
                
                del_list = []
                for idx in xrange( new_ava_processes ):
                    subprocess.Popen( ["python", multi_runner_path, pickle.dumps(rebuild_total_info[idx]), env  ] )
                    del_list.append( rebuild_total_info[idx] )
                for idx in xrange( new_ava_processes ):
                    rebuild_total_info.remove( del_list[idx] )
                counter = counter + new_ava_processes
            
        except:
            urllib2.urlopen( fatal_url , json.dumps({"token": token, "crashed_of": traceback.format_exc() })).read()
        finally:
            if client.exists(busy_path):
                client.delete( busy_path ) 
            try: os.remove( client_pid_path )
            except: pass

# -*- coding:utf-8 -*-

import os, sys, yaml, urllib2, json

file_path = os.path.dirname(os.path.abspath(__file__)) + "/../"
sys.path.append( file_path )
from  util.data import dh
from business import test_obj
from business.data import UtilData
from run.step import run_step

import traceback

def run( data, testsets, env ):
    
    config  = yaml.load( open( file_path + "config/basic.yaml" ).read() )
    
    feedback_url = config["worker"] % env
    
    ttsk = test_obj.TestTask( **data )
    params_for_utdata =   dh.comb_dict( ttsk.components, ttsk.constants, ttsk.ui_pool )
    utdata = UtilData( **params_for_utdata )
    all_rs = []
    
    for  testset  in testsets:
        ttset = test_obj.TestSet( **testset )
        for  testcase in ttset.testset:
            ttcase = test_obj.TestCase( **testcase )
            retry_times = 1
            
            try:
                for i in range( retry_times ):
                    utdata.clear_result( len(ttcase.steps), testset=ttset.id, testcase=ttcase.id, token=ttsk.token )
                    for  step in ttcase.steps:
                        sp = test_obj.TestStep( **step )
                        
                        if utdata.continue_flag == True:
                            
                            run_step( sp, utdata, ttcase )  
                            
                        else: break
                    
                    utdata.fin_summary()
                    
                    if utdata.result["result"] == "PASS" or utdata.result["result"] == "ERROR":
                        all_rs.append( utdata.result )
                        try:
                            urllib2.urlopen( feedback_url, json.dumps( utdata.result ) )
                        except:
                            urllib2.urlopen( feedback_url, json.dumps( utdata.result) )
                        break
                    
                    else:
                        
                        if  i==retry_times - 1:
                            all_rs.append( utdata.result )
                            try:
                                urllib2.urlopen( feedback_url, json.dumps(utdata.result) )
                            except:
                                urllib2.urlopen( feedback_url, json.dumps( utdata.result) )
            except:
                err_result = utdata.result
                err_result["result"] = "FATAL"
                err_result["crashed_of"] = "用例执行发生异常: %s" % traceback.format_exc()
                err_result["token"] = ttsk.token
                err_result["testcase"] = ttcase.id
                err_result["testset"] = ttset.id
                urllib2.urlopen( feedback_url, json.dumps(utdata.result) )
                    
            
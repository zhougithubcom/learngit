# -*- coding: utf-8 -*-

import os, sys, psutil, re, signal,  urllib2, json, yaml
from kazoo.client import KazooClient
file_path = os.path.dirname( os.path.abspath(__file__) ) + "/../"
sys.path.append( file_path )
from util.system.system import get_machine_ip

def  shutdown( token, env, callback_url ):
    
    ptoken = None
    try:
        client_pid_path = file_path + "config/pid/%s_client_pid.pid" % token
        if os.path.exists( client_pid_path ) and len( open(client_pid_path).readlines() ) != 0:
            pid = open( client_pid_path ).readlines()[0].strip()
            if re.match( '^\d+$', pid):
                pid = int( pid )
                ptoken = None
                if  len( open(client_pid_path).readlines() ) == 2:
                    ptoken = open( client_pid_path ).readlines()[-1]
            else:
                os.remove( client_pid_path )
                
            if ptoken == token:
                try: 
                    pname = psutil.Process(pid).name()
                    if "python" == pname.lower():
                        chdpids = [ cpid.pid for cpid in psutil.Process(pid).children() if cpid.status() != "zombie"]
                        os.kill( pid, signal.SIGTERM )
                        for chdpid in chdpids: 
                            try : os.kill( chdpid, signal.SIGKILL )
                            except: continue
                    os.remove( client_pid_path )
                except psutil.NoSuchProcess:
                    os.remove( client_pid_path )
            else:
                os.remove( client_pid_path )
                
        urllib2.urlopen( callback_url, json.dumps({"token": token, "success": True}) ).read( )
    except: 
        urllib2.urlopen( callback_url, json.dumps({"token": token, "success": False }) ).read( )
    
    if ptoken == token:
        kazooserver = yaml.load( open( file_path+"config/basic.yaml" ).read() )["zookeeper"]
        client = KazooClient( kazooserver )
        client.start()
        if client.exists( "/mitest/%s/busy/%s/%s" % ( env, get_machine_ip(), token ) ):
            client.delete( "/mitest/%s/busy/%s/%s" % ( env, get_machine_ip(), token ) )

if __name__ == "__main__":
    token = sys.argv[1]
    env = sys.argv[2]
    
    callback_url = yaml.load( open( file_path + "config/basic.yaml").read() )["stopper"] % env 
    
    shutdown(token, env, callback_url)
    
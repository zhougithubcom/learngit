#-*- coding: utf-8 -*-

import os, sys, time ,re , copy, datetime, json, yaml
from business.test_obj import UtilMapper, TestStep
file_path = os.path.dirname( os.path.abspath(__file__) ) + "/../"
sys.path.append( file_path )
from util.data import dh
import traceback

reload(sys)
sys.setdefaultencoding("utf-8")

utmapper = UtilMapper( **yaml.load(open(file_path+"config/util_mapper.yaml").read() ) ) 

def  run_step( step, utdata, testcase ):
    
    result = ()
    
    delay_time, after_time = int(step.delay.split(",")[0]), int( step.delay.split(",")[1] )
    cirtimes = int( step.retry ) + 1
    
    delkeys = [ "delay", "retry" ]
    if type( step.execute.params ) == type( {} ):
        step.execute.params = dh.del_key_from_dict( step.execute.params, *delkeys )
     
    mod = ""
    
    if "::" in step.execute.method:
        instance, method = step.execute.method.split("::")
        mod = instance.split(".")[-1]
    else:    
        result = ( None, "传递的method字段不是规范的格式，因此无法进行后续操作。基本格式类似于abc.bb::td， 当前格式为：%s" % step.execute.method )
    
    assoc_step = step.execute.based_step
    if mod == "assert" and ( assoc_step not in [ssp["id"] for ssp in  testcase.steps] ) and result ==()  and assoc_step != None:
        result = ( None, "当前执行的测试步骤关联的步骤不存在，请检查是否使用了错误的关联信息。关联步骤的id为：%s"  %  step.execute.based_step )
    
    start_time = time.time()
    
    for i in range( int(cirtimes) ):
        
        if  result == ():
            import_line = getattr( utmapper,  instance )
            if import_line == None:
                result = ( None, "测试步骤：需要调用的模块未在/config/util_mapper.yaml中做映射，因此无法定位到执行器对应的模块" )
            else:
                exec  import_line
                klass = re.search( r"import +(\w+)", import_line ).group(1)
                acinst = eval(klass)()
                time.sleep( delay_time )
                try:
                    result = getattr( acinst, method )(step, utdata)
                except:
                    result = (None,"模块%s不包含%s方法，请检查是否步骤关联失败或者执行代码未做更新; %s"  %  (instance, method, traceback.format_exc()) )
                time.sleep( after_time )
        else:
            time.sleep( delay_time )
            try:
                result = getattr( acinst, method )( step, utdata )    
            except:
                result = (None,"模块%s不包含%s方法，请检查是否步骤关联失败或者执行代码未做更新"  %  (instance, method) )
        
        execute_time = "%0.3f" % ( time.time() - start_time )
        if result[0] == True:
            utdata.record_info( step.id, result, execute_time, utdata )
            if instance.split(".")[-1] == "assert": utdata.update_counter( result[0] )
            break
        elif result[0] == None:
            utdata.record_info( step.id, result, execute_time, utdata )
            utdata.update_counter( result[0] )
            if step.execute.essential_step :
                utdata.chg_continue_flag()
            break
        else:
            if i != cirtimes-1:
                utdata.update_repeat_results( step.id, i, result )
            else:
                utdata.record_info( step.id, result, execute_time, utdata )
                if mod == "assert":
                    utdata.update_counter( result[0] )
                    whole_sp_mapper_ess = {}
                    for step in testcase.steps:
                        step = TestStep( **step )
                        whole_sp_mapper_ess[step.id] = step.execute.essential_step
                else:
                    if step.execute.essential_step:
                        utdata.chg_continue_flag()
                break
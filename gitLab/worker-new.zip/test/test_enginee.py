#-*- coding: utf-8 -*-

data_pool = { "xiao1": "y", "xiao2": "l", "xiao3": 3, "xiao4": "qqto" , "xiao": 6}

import os, sys
sys.path.append( os.path.dirname(os.path.abspath(__file__)) + "/../" )
from util.data import dh


test_data1 = '{{ $xiao1}}'
test_data2 = '{{$xiao3+$xiao}}'
test_data3 = '{{$xiao2}}}b{{$xiao3}}{{{"map": $xiao2}}}'
test_data4 = '{{{"pk4": $xiao1}}'
test_data5 = '{{ {"a":1}, 2}}'
test_data6 = {"b": "{{$xiao1}}", "d": {"{{$xiao2}}": "{{$xiao}}" }}

print dh.param_rebuild(test_data1, data_pool)
print dh.param_rebuild(test_data2, data_pool)
print dh.param_rebuild(test_data3, data_pool)
print dh.param_rebuild(test_data4, data_pool)
print dh.param_rebuild( test_data5, data_pool)
print dh.param_rebuild(test_data6, data_pool)

import json
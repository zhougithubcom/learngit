# -*- coding: utf-8 -*-

import os, sys

sys.path.append( os.path.dirname( os.path.abspath(__file__) ) + "/../" )

from business import custom_http  as ch

if __name__ == "__main__":

    '''需要注意host字段和proxy字段不能同时使用,proxy有可能会将host直接设置为域名'''
    #  依赖于x5协议的调用方式
    x5header = { "user_name": "dawei", "appid": "xm_1018", "user_id": "1232456", "key": "Hxvr4y58pdSfbaEq7wVR3tY2OZDPzsJUBnAKGNj0gCWluh16ekLX9MTIcFmoQi" }
    x5body = {"orderList": [{"settings": {"a": 1}, "order_id": "1001"}]}
    url = "http://oc3.t.n.api.b2c.srv/security/check"
    '''当提供的访问域名不需要绑定host访问 '''
    print ch.request_in_x5( x5header, x5body, url )
    '''当提供的访问域名需要绑定host访问'''
    print ch.request_in_x5( x5header, x5body, url, host="10.237.39.41") 
     
    #  依赖于shopapi协议的调用方式
    shopapi_params = { "appid": "10001", "appkey": "verify_key_test", 
                      "client_id": "180100031035", "client_mihome_id": "0", "ids": "1001", "type": "S2G"  }
    shopapi_url = "http://sgp.shopapi.t.n.b2c.srv/product/transform"
    '''当提供的访问域名不需要绑定host访问 '''
    print ch.request_in_shopapi(shopapi_params, shopapi_url )
    '''当提供的访问域名需要绑定host访问'''
    print  ch.request_in_shopapi( shopapi_params, shopapi_url, host="10.237.39.4")
    
    #  key center  加密解密调用
    data = "好好的^"
    de_data = "GBBVamrzTXVzwddGw6yHHxScGBLP5jk3IIRHK5WwDzVyhWroEf8YEPllZW9jdUQZnF6+k+k05VYYFGhNsPWi/7guIKPgrwAS+Oz4etJqEwEA"
    de_err_data = "不能解密"
    '''加密'''
    print ch.crypt_data( data, "encrypt" )
    '''解密'''
    print ch.crypt_data( de_data, "encrypt" )
    '''解密, 失败返回False'''
    print ch.crypt_data( de_data, "decrypt" )
    '''解密, 失败返回True'''
    print ch.crypt_data( de_err_data, "decrypt", True )
    
    
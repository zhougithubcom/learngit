# -*- coding: utf-8 -*-

import os, sys

sys.path.append( os.path.dirname(os.path.abspath(__file__)) + "/../" )

from business.databases import Backend

if __name__ == "__main__":
    
    backend = Backend()
    query_sql = "select * from xm_order where order_id='1160526642201336'"
    print backend.find_one( query_sql )
    query_sql2= "select * from xm_order limit 10"
    print backend.find_all(query_sql2)
    
    '''delete/update都使用backend.update( sql语句 )进行调用, 这里不给出例子提示'''
    
    '''对于多站点同结构不同配置的数据库, 提供country字段进行区分, 不填写country时，默认为cn站'''
    backend_overseas = Backend( "overseas" )
    print backend_overseas.find_one( query_sql )
    print backend_overseas.find_all( query_sql2 )
    
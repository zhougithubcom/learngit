#-*- coding: utf-8 -*-

if __name__ == "__main__":
    
    data = '{"m": 1}'


#-*- coding: utf-8 -*-

import os, sys

file_path = os.path.dirname( os.path.abspath(__file__)) + "/../"
sys.path.append( file_path )

from ui_automation.ui import UiUtil
from business.struct import TestStep
from business.data import UtilData
from selenium.webdriver.common.keys import Keys

utdata = UtilData( **{})
uu = UiUtil()
'''
step_init = TestStep( **{"execute": {"params": {"browser": "ff" } }  } )
uu.browser_init( step_init, utdata )
 
step_get = TestStep( **{ "execute": {"params": {"url": "http://www.baidu.com", "browser": "ff"} } } )
uu.get( step_get, utdata  )
 
step_input = TestStep( **{"execute": {"params": {"properties": "id", "values": "kw", "browser": "ff", "text": "hello world" }}} )
uu.set_text( step_input, utdata )
 
step_return = TestStep( **{"execute": {"params": {"properties": "id", "values": "su", "browser": "ff", "keyboard":"return" }}} ) 
uu.set_keybord( step_return, utdata ) 
 
step_f11 = TestStep( **{"execute": {"params": {"properties": "id", "values": "su", "browser": "ff", "keyboard":"f11" }}} )
uu.set_keybord( step_f11, utdata )

step_backspace = TestStep( **{"execute": {"params": {"properties": "id", "values": "su", "browser": "ff", "keyboard":"backspace" }}} )
uu.set_keybord( step_backspace, utdata )
'''

step_web = TestStep( **{"execute": {"params": {"browser": "ff"}}} )
uu.browser_init(step_web, utdata)

step_url = TestStep( **{"execute": {"params": {"browser": "ff", "url": "http://www.mi.com/buyphone/"}}} )
uu.goto( step_url, utdata )
import time 
time.sleep(3)
from selenium.webdriver.common.by import By
utdata.browser["ff"].find_element( By.XPATH, "//img[@src='//i3.mifile.cn/a4/T1K2ZjB4Dv1RXrhCrK.jpg']" ).click()
# utdata.browser["ff"].find_element(By.XPATH, "/html/body/div[3]/div[4]/ul/li[1]/div[1]/a/img").click()

# time.sleep(3)
# # utdata.browser["ff"].switch_to_window(  utdata.browser["ff"].window_handles[-1]  )
# 
# utdata.browser["ff"].find_element(By.XPATH, "//a[text()='意外保']").click()

# for ub in  utdata.browser["ff"].window_handles:
#     utdata.browser["ff"].switch_to_window(ub)



# send_keys_f11 = TestStep( **{"execute": {"params": {"browser": "ff", "keyboard": "f11", "properties": "tag", "values": "p"}}})
# print uu.set_keybord(send_keys_f11, utdata)

# step_username = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "id", "values": "miniLogin_username", "text": "lvyanliang"}}})
# uu.set_text( step_username, utdata )
# step_passwd = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "id", "values": "miniLogin_pwd", "text": "Y1989918l!@"}}})
# uu.set_text( step_passwd, utdata )
# 
# # uu.get_text( step_passwd, utdata )
# # uu.get_value( step_passwd, utdata )
# 
# login_button = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "id", "values": "message_LOGIN_IMMEDIATELY"}}} )
# uu.click( login_button, utdata )
# step_project_url = TestStep(  **{"execute": {"params": {"browser": "ff",  "url": "http://miload.mitest.cn/#/mission/9/panel" }}})
# uu.goto( step_project_url, utdata )
# 
# step_more_info = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "xpath", "values": "//table[@class='aui']//tr[@class='mission-panel-job-item ng-scope'][3]//span[text()='详细信息']" }}} )
# 
# import time
# time.sleep(3)
# uu.click( step_more_info, utdata )

# config_param_btn = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "xpath", "values": "//table[@class='aui']//tr[@class='mission-panel-job-detail-container ng-scope'][3]//span[text()='配置参数']"}}} )
# uu.wait_until_clickable( config_param_btn, utdata )
# uu.click( config_param_btn, utdata )

# time.sleep(2)
# login_modal = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "xpath", "values": "//*[@id='demo-dialog']//select[1]"} }  } )
# uu.is_enabled(login_modal, utdata)
# 
# login_callback_select_l1s1 = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "xpath", "values": "//*[@id='demo-dialog']//select[1]" , "text": "CN_PC_3000_540001"}}} )
# login_callback_select_l1s2 = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "xpath", "values": "//*[@id='demo-dialog']//select[2]", "text": "logincallback" }}} )
# login_callback_select_l1s3 = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "xpath", "values": "//*[@id='demo-dialog']//select[3]", "value": "1" }}} )
# 
# uu.select_by_visible_text( login_callback_select_l1s1, utdata )
# uu.select_by_visible_text( login_callback_select_l1s2, utdata )
# uu.select_by_value( login_callback_select_l1s3,  utdata )
# 
# confirm_btn = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "xpath", "values": "//*[@id='demo-dialog']//button[text()='保存']"}}} )
# uu.click( confirm_btn, utdata )
# 
# print uu.scroll_element_into_view(config_param_btn, utdata)

# time.sleep(2)
# alert_call = TestStep( **{"execute": {"params": {"browser": "ff", "javascript": "alert('r u stupid?')"}}} )
# uu.execute_javascript(alert_call, utdata)
# alert_call = TestStep( **{"execute": {"params": {"browser": "ff", "javascript": "confirm('r u stupid?')"}}} )
# uu.execute_javascript( alert_call, utdata)

# config_param_btn2 = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "tag", 
#                                                         "values": "p", 
#                                                         "movements": "key_down>>key_down", "arguments": "[\"alt\"]>>[\"w\"]"}}} )
# print uu.custom_movement( config_param_btn2, utdata )


# close_browser_step = TestStep( **{"execute": {"params": {"browser": "ff"}}})
# print uu.close_browser( close_browser_step, utdata)

# step_more_info1 = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "xpath", "values": "//span[text()='详细信息']/ancestor::button", "attribute": "class" }}} )
# uu.get_attr( step_more_info1, utdata )
# uu.get_text( step_more_info1, utdata ) 
# uu.get_html( step_more_info1, utdata )
# step_more_info2 = TestStep( **{"execute": {"params": {"browser": "ff", "properties": "xpath", "values": "//span[text()='详细信息']", "css_property": "width" }}} )
# uu.get_css( step_more_info2, utdata )
# uu.is_displayed(step_more_info2, utdata)
# uu.is_enabled(step_more_info2, utdata)



#-*- coding: utf-8 -*-




from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.alert import Alert

import os, sys, json
from selenium.webdriver.support.wait import WebDriverWait
file_path = os.path.dirname( os.path.abspath(__file__) ) + "/../"
sys.path.append( file_path )
import traceback
from ui_automation.ui_base import UiBase
from business.decorator import action, ui_action

'''需要添加截图的后置操作'''

class  UiUtil( UiBase ):

    keybords = ['ADD', 'ALT', 'ARROW_DOWN', 'ARROW_LEFT', 'ARROW_RIGHT', 'ARROW_UP', 'BACKSPACE', 
                'BACK_SPACE', 'CANCEL', 'CLEAR', 'COMMAND', 'CONTROL', 'DECIMAL', 'DELETE', 'DIVIDE', 
                'DOWN', 'END', 'ENTER', 'EQUALS', 'ESCAPE', 'F1', 'F10', 'F11', 'F12', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 
                'F9', 'HELP', 'HOME', 'INSERT', 'LEFT', 'LEFT_ALT', 'LEFT_CONTROL', 'LEFT_SHIFT', 'META', 'MULTIPLY', 
                'NULL', 'NUMPAD0', 'NUMPAD1', 'NUMPAD2', 'NUMPAD3', 'NUMPAD4', 'NUMPAD5', 'NUMPAD6', 'NUMPAD7', 
                'NUMPAD8', 'NUMPAD9', 'PAGE_DOWN', 'PAGE_UP', 'PAUSE', 'RETURN', 'RIGHT', 'SEMICOLON', 
                'SEPARATOR', 'SHIFT', 'SPACE', 'SUBTRACT', 'TAB', 'UP']

    @action
    @ui_action
    def  goto( self, step, utdata ):
        
        browser = self.get_browser(step.execute.params, utdata)
        if browser == None:
            return False, "没有浏览器对象"
        browser.set_page_load_timeout(5)
        url = step.execute.params.get("url")
        if url:
            try:
                browser.get( url )
                return True, None
            except:
                return False, "请检查提供的url是否正常"
        else:
            return False, "没有提供必要的url信息"


    def  get_windows( self, step, utdata ):
        
        pass
    
    @action  
    @ui_action      
    def click( self, step, utdata ):  return self.do( step.execute.params, utdata, "click", False )

    @action  
    @ui_action 
    def  set_text( self, step, utdata ): return self.do( step.execute.params, utdata, "send_keys", False , step.execute.params.get("text") )

    @action  
    @ui_action 
    def  set_keybord( self, step, utdata ): 
        
        key = step.execute.params.get("keyboard")
        if  key != None:
            if key.upper() not in self.keybords:
                return  self.do( step.execute.params, utdata, "send_keys", False, key )
            else:
                return self.do( step.execute.params, utdata, "send_keys", False, getattr( Keys, key.upper() ) )
        else:
            return False, "没有提供键盘按钮信息"     

    @action  
    @ui_action 
    def  clear( self, step, utdata ): return  self.do( step.execute.params, utdata, "clear", False ) 
    
    @action  
    @ui_action 
    def  submit( self, step, utdata ): return self.do( step.execute.params, utdata, "submit", False )
    
    @action  
    @ui_action 
    def  select_by_index( self, step, utdata ): return self.select( step.execute.params, utdata, "select_by_index", False, step.execute.params.get("index", 0) )
    
    @action  
    @ui_action 
    def  select_by_value( self, step, utdata ): return self.select( step.execute.params, utdata, "select_by_value", False, step.execute.params.get("value", "") )

    @action  
    @ui_action    
    def  select_by_visible_text( self, step, utdata ): return self.select( step.execute.params, utdata, "select_by_visible_text", False, step.execute.params.get("text", "" ) )
    
    @action  
    @ui_action 
    def  wait_until_present( self, step, utdata ): return self.wait_element(step, utdata,  "presence_of_element_located")
    
    @action  
    @ui_action 
    def  wait_until_visibility(self, step, utdata): return self.wait_element(step, utdata, "visibility_of_element_located" )
    
    @action  
    @ui_action 
    def  wait_when_visibility( self, step, utdata ): return self.wait_element(step, utdata, "invisibility_of_element_located" )
    
    @action  
    @ui_action 
    def  wait_until_clickable( self, step, utdata ): return  self.wait_element(step, utdata, "element_to_be_clickable" )

    @action  
    @ui_action 
    def  switch_browser( self, step, utdata ):
        
        browser = self.get_browser(step.execute.params, utdata)
        if browser:
            try:
                browser.switch_to_window( browser.window_handles[-1] )
                utdata.browser[step.execute.params["browser"]] = browser
                return True, "切换窗口成功"
            except:
                return False, "切换窗口失败"
        else:
            return False, "获取浏览器对象失败"
    
    @action
    @ui_action
    def  get_url (self, step, utdata ):
        browser = self.get_browser(step.execute.params, utdata)
        if browser:
            return True, browser.current_url
        else:
            return None, "未获取到浏览器对象"
     
    @action  
    @ui_action    
    def  get_attr( self, step, utdata ):
        
        return self.get( step.execute.params, utdata, "get_attribute", step.execute.params.get("attribute") )
    
    @action  
    @ui_action 
    def  get_css( self, step, utdata ):
        
        return  self.get( step.execute.params, utdata, "value_of_css_property", step.execute.params.get("css_property") )


    @action  
    @ui_action 
    def  get_text( self, step, utdata ):
        
        return self.do( step.execute.params, utdata, "text", True  )
    
    @action  
    @ui_action 
    def  get_value( self, step, utdata ):
        
        return  self.get( step.execute.params, utdata,  "get_attribute", "value" )
    
    @action  
    @ui_action 
    def  get_html( self, step, utdata ):
        
        return self.get( step.execute.params, utdata, "get_attribute", "innerHTML" )
    
    @action  
    @ui_action 
    def  is_displayed( self, step, utdata ):

        flag, result = self.get( step.execute.params, utdata, "is_displayed" )
        return  flag and result, ""
    
    @action  
    @ui_action 
    def  is_enabled( self, step, utdata ):
        
        flag, result = self.get( step.execute.params, utdata, "is_enabled" )
        return flag and result, ""
    
    @action  
    @ui_action 
    def  is_selected( self, step, utdata ):
        
        flag, result = self.get( step.execute.params, utdata, "is_selected" )
        return flag and result,  ""
    
    @action  
    @ui_action 
    def  execute_javascript( self, step, utdata ): 
        
        browser = self.get_browser( step.execute.params, utdata)
        if browser :
            try:
                browser.execute_script( step.execute.params.get("javascript") )
                return True, ""
            except:
                return False, "调用js执行操作失败"
        else:
            return False, "没有找到浏览器对象"

    @action  
    @ui_action 
    def  scroll_element_into_view( self, step, utdata ):
        
        return self.do(step.execute.params, utdata, "location_once_scrolled_into_view", True )
    
    @action  
    @ui_action     
    def  custom_movement( self , step, utdata ):
        
        params = step.execute.params
        browser = self.get_browser( params, utdata )
        movements = params.get("movements", "").split(">>")
        arguments = params.get("arguments", "").split(">>")
        if browser: 
            element = self.locate_element(step.execute.params, browser)
            if element:
                try:
                    ac = ActionChains( browser )
                    ac.move_to_element(element)
                    for idx, movement in enumerate( movements ):
                        args = json.loads( arguments[idx] )
                        if "key" in movement:
                            for idx, arg in enumerate(args):
                                if arg.upper() in self.keybords :
                                    args[idx] = getattr( Keys, arg.upper() )
                        ac = getattr( ac, movement )( *args )
                    ac.perform()
                    return True, ""
                except:
                    import traceback
                    print traceback.format_exc()
                    return False, "操作失败"
            else:
                return False, "无法定位到元素"
        else:
            return False, "无法获取到浏览器对象"
        
    @action
    @ui_action    
    def  get_alert_text( self , step, utdata ):
        
        browser = self.get_browser( step.execute.params, utdata )
        if browser:
            try: return True, Alert(browser).text
            except: return False, "没有发现弹层"
        else:
            return None, "无法获取到浏览器对象"
    
    @action
    @ui_action
    def  send_alert_keys( self, step, utdata ):
        
        browser = self.get_browser( step.execute.params, utdata )
        if browser:
            try:  
                Alert(browser).send_keys(step.execute.params["data"])
                return True, "填写alert完毕"
            except:  return False, "向alert填写数据失败"
        else:
            return None, "无法取得浏览器对象"
    
    @action
    @ui_action
    def  alert_ok(self, step, utdata) :
        browser = self.get_browser( step.execute.params, utdata )
        if browser:
            try:
                Alert(browser).accept()
                return True, "点击alert确认按钮完成"
            except:
                return False, "没有发现弹层"
        else:
            return None, "无法取得浏览器对象"
        
    @action
    @ui_action
    def  alert_dismiss(self , step ,utdata):
        browser = self.get_browser( step.execute.params, utdata )
        if browser:
            try: 
                Alert(browser).dismiss()
                return True, "点击取消alert操作成功"
            except:
                return False, "没有发现弹层"
        else:
            return   None, "没有发现浏览器对象"
        
    @action
    @ui_action 
    def  alert_authen(self, step , utdata):
        
        browser = self.get_browser( step.execute.params, utdata) 
        if browser:
            try:
                Alert(browser).authenticate(step.execute.params.get("username"), step.execute.params.get("passwd") )
                return True, "尝试登录操作完成"
            except:
                return False, "操作登录操作失败"
        else:
            return None, "没有发现浏览器对象"      
    
    @action
    @ui_action
    def  alert_send_text(self, step, utdata ):
        browser = self.get_browser( step.execute.params, utdata )
        if browser:
            keyword = step.execute.params.get("keyword")
            if  keyword:
                try:
                    browser.switch_to_alert()
                    if keyword.upper() in self.keybords:
                        Alert(browser).send_keys( self.keybords[keyword.upper()] )
                    else:
                        Alert(browser).send_keys(keyword)
                except:
                    return False, "无法向浏览器弹层弹出数据"
            return True, ""
        else:
            return None, "没有发现浏览器对象"
            
    @action
    @ui_action
    def  get_cookie(self, step, utdata):
        
        browser = self.get_browser( step.execute.params, utdata )
        if browser:
            try: 
                data = browser.get_cookie( step.execute.params["cookie_name"] )
                if data == None: return True, ""
                else: return True, data
            except:
                return False, "没有获取到cookie信息: %s" % traceback.format_exc()
        else:
            return None, "没有获取到浏览器对象"

    @action
    @ui_action
    def  switch_to_alert(self, step, utdata):
        browser = self.get_browser( step.execute.params, utdata )
        if browser:
            try:
                browser.switch_to_alert()
                return True, ""
            except:
                return False, "当前窗口不存在alert"
        else:
            return None, "没有获取到浏览器对象" 
            
    
    @action  
    @ui_action     
    def  drag( self, step, utdata ):
        pass
    
    @action  
    @ui_action 
    def  drag_and_drop( self, step, utdata  ):        
        pass


    @action
    @ui_action
    def switch_frame(self, step, utdata):
        browser = self.get_browser(step.execute.params, utdata)
        if browser:
            try:
                browser.switch_to_alert()
                return True, ""
            except:
                return False, "当前窗口不存在alert"
        else:
            return None, "没有获取到浏览器对象"

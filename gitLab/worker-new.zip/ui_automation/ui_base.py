# -*- coding: utf-8 -*-

import traceback
from selenium import webdriver as wb
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities  as dc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import UnexpectedAlertPresentException

class  UiBase( object ):
    
    browser_mapper = { "ff": wb.Firefox, "chrome": wb.Chrome, "ie": wb.Ie, 
                    "edge": wb.Edge, "opera": wb.Opera, "safari": wb.Safari,  "andriod": wb.Android }
    remote_browser_mapper = { "ff": dc.FIREFOX, "chrome": dc.CHROME, "ie": dc.INTERNETEXPLORER,
                    "edge": dc.EDGE, "opera": dc.OPERA, "safari": dc.SAFARI, "andriod": dc.ANDROID }
    by_mapper = { "id": By.ID, "class": By.CLASS_NAME, "css":  By.CSS_SELECTOR, "link_text": By.LINK_TEXT, 
             "name": By.NAME, "partial_link_text": By.PARTIAL_LINK_TEXT, "tag": By.TAG_NAME, "xpath": By.XPATH }

    
    def  browser_init( self, step, utdata ):
        
        params = step.execute.params
        browser_name = params["browser"]
        
        if browser_name not in self.browser_mapper.keys():
            return False, "不支持的浏览器类型"
        
        try:
            if params.get("profile") == True and browser_name == "ff":
                profile = "/root/.mozilla/firefox/od40j4sh.default"
                utdata.browser[browser_name] = self.browser_mapper[browser_name](profile)
            else:
                utdata.browser[browser_name] = self.browser_mapper[browser_name]()

            utdata.browser[browser_name].maximize_window()
            return  True, browser_name
        except:
            return False, "请检查浏览器驱动是否在全局变量中进行了设置"

    def  browser_remote_init( self, step, utdata ):    

        params = step.execute.params

        remote_url = params["remote_url"]
        browser_name = params["browser"]
        if browser_name not in self.browser_mapper.keys():
            return False, "不支持的浏览器类型"
        try:
            utdata.browser[browser_name+"-remote"] = wb.Remote( command_executor=remote_url,
                desired_capabilities=self.remote_browser_mapper[browser_name] )
            return True, browser_name+"-remote"
        except:
            return False, "请检查浏览器驱动是否运行正常/remote服务端是否开启"
    
    def  locate_element( self, obj_data, browser ):
        
        element = browser
        pros = obj_data["properties"].split(">>")
        values = obj_data["values"].split(">>")
        for  idx, pro in enumerate(pros):
            value = values[idx]
            try: 
                element = element.find_element( by=self.by_mapper[pro], value=value )
            except: return None
        return element    

    def  wait_element( self, step, utdata, method_name  ):
        params = step.execute.params
        browser = self.get_browser(params, utdata)
        if browser:
            timeout = int( step.execute.params.get("timeout", 10) )
            pro = params["properties"]
            value = params["values"]
            try:
                WebDriverWait( browser, timeout ).until( getattr( ec, method_name )( (self.by_mapper[pro], value) ) )
                return True, ""
            except:
                return False, "不符合等待条件，操作失败"
        else:do

            return False, "无法获取浏览器对象"
    
    
    def  get_browser(self , params, utdata ):
        
        browser_name = params.get("browser")
        if browser_name:
            return utdata.browser.get( browser_name )
        else:
            return None

    def  close_browser( self, step, utdata ):
        
        browser_name = step.execute.params.get("browser")
        if browser_name:
            browser = utdata.browser.get(browser_name)
            if browser:
                try:
                    browser.quit()
                    del utdata.browser[browser_name]
                    return True, ""
                except UnexpectedAlertPresentException:
                    return self.close_browser(  step, utdata )
                except:
                    return False, traceback.format_exc()
            else:
                return True, ""
        else:
            return True, ""

        
    def  do( self, params, utdata, method_name,  attribute=False , *args ):
        
        browser = self.get_browser( params, utdata )
        if browser:
            element = self.locate_element( params, browser)
            if element:
                try: 
                    if not attribute:
                        getattr( element, method_name )( *args )
                        return True, ""
                    else:
                        return True, getattr( element, method_name )
                except:
                    import traceback
                    print traceback.format_exc()
                    return False, "执行调用操作失败"
            else:
                return False, "无法定位元素"
        else:
            return False, "没有获取到浏览器对象, 无法进行操作"

    def  select( self, params, utdata, method_name,  attribute=False , *args ):
        
        browser = self.get_browser( params, utdata )
        if browser:
            element = self.locate_element( params, browser)
            if element:
                try: 
                    if not attribute:
                        getattr( Select(element), method_name )( *args )
                        return True, ""
                    else:
                        return True, getattr( element, method_name )
                except:
                    import traceback
                    print traceback.format_exc()
                    return False, "执行调用操作失败"
            else:
                return False, "无法定位元素"
        else:
            return False, "没有获取到浏览器对象, 无法进行操作"    
        
    def  get( self, params, utdata, method_name, *args ):
        
        browser = self.get_browser(params, utdata)
        if browser:
            element = self.locate_element( params, browser)
            if element:
                try: 
                    return True, getattr( element, method_name ) ( *args )
                except:
                    return False, "执行调用操作失败"
            else:
                return False, "无法定位元素"
        else:
            return False, "没有获取到浏览器对象, 无法进行操作"    
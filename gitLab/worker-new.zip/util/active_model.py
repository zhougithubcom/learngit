# -*- coding: utf-8 -*-

class ActiveModel( object ):
    
    def __init__ (self , **args ):
        
        self.hash_all = args
        for arg_name, arg_value in args.iteritems(): 
            if type(arg_value) == type( {} ):
                for  lv2_arg_name, lv2_arg_value in arg_value.iteritems():
                    setattr( self, arg_name, self )
                    setattr( getattr(self, arg_name), lv2_arg_name, lv2_arg_value )
                setattr( getattr(self, arg_name), "all", arg_value )
            else:
                setattr( self, arg_name, arg_value )
    
    def  __getattr__(self, name):
        
        value = None
        try: value = object.__getattribute__( self, name )
        except: pass
        return value
    

class  ActiveModelSig(object):
    
    def __init__(self, **args):
        for arg_name, arg_value in args.iteritems():
            setattr( self, arg_name, arg_value )
    
    def  __getattr__( self , name ):
        value = None
        try: value = object.__getattribute__(self, name)
        except: pass
        return value
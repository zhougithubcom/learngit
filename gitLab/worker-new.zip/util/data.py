# -*- coding: utf-8 -*-

import  copy, re
import urllib
#  提供一个数据操作模块类
class  DataUtil( object ):
    '''所有的方法都不能对原始数据进行改动'''
    
    # 根据提供的键位获取值，当depth为True时, 默认>>为路径标识
    def  get_depth_data( self,  origin_data, format_path, depth=True ):    
        
        expect_data = copy.deepcopy(origin_data)    
        format_array = [ format_path ]
        if depth : format_array = format_path.split(">>")
        for element in format_array:
            element = "expect_data%s" % re.sub( r'(?!\[)(\w+)(?!\])', r".get('\1')", element )
            try: expect_data = eval( element )
            except: return False, expect_data
        if expect_data == None: return False, expect_data
        else: return True, expect_data
        
            
    #  检查dict的keys中是否包含全部的key_paths
    def  check_key_in_map( self, dict_info, *key_paths ):
        
        missing_path = []
        for path in key_paths:
            result  = self.get_depth_data( dict_info,  path )
            if result[0] == False: 
                missing_path.append(path)
        if missing_path == []:
            return True, []
        else:
            return False, missing_path

    
    def  check_keyvalue_in_list(self, list_info, keyword):
        
        for element in list_info:
            for element_depth in element.values():
                for  element_depp in element_depth.values():
                    if element_depp == keyword: return True    
        return False            


    def  xencode( self, ainfo ):
        ntw = {}
        for key, value in ainfo.iteritems():
            if isinstance( value, str):
                value = value.decode("utf-8")
                ntw[key] = value
            elif isinstance( value, list ):
                fin_list = []
                for element in value:
                    if type(element) == type({}) : fin_list.append( self.xencode(ainfo) )
                    elif type(element) == type([]): pass
                    elif isinstance( element, str ): fin_list.append( value.decode("utf-8") )
                    else: fin_list.append( element )
                ntw[key] = fin_list
            elif  type(value) == type({}):
                ntw[key] = self.xencode(value)
            else:
                ntw[key] = value
        return ntw
                        
    def  comb_dict(self, origin_data, *outer_data):
        
        data = dict( copy.deepcopy(origin_data) )
        for otd in outer_data:
            data = dict( data or {}, **( otd or {} ) )
        return data 

    def  del_key_from_dict(self , dict_info, *keys ):
        
        dict_info = dict_info or {}
        if len( dict_info )==0: return dict_info
        try: new_dict_info = dict( copy.deepcopy( dict_info ) )
        except:  return dict_info
        
        for key in keys:
            if key in dict_info.keys(): new_dict_info.pop( key )
        return new_dict_info
    

        
    def  cp_dict( self, origin_dict ):
        
        return dict( copy.deepcopy(origin_dict) )          
    
    def  filter_pattern( self,  data ):
        
        pattern_all = []
        pattern_part = []
        exist_depth = 0
        length  = len( data )
        if length < 4 or "{" not in data:
            return True, data, []
        for idx, bd in enumerate( data ):
            if bd not in ['{','}']:
                if exist_depth > 0 : 
                    pattern_part.append(bd)
                    continue
                else: continue
            elif bd == '{':
                if idx == 0 and data[idx+1] == '{':
                    pattern_part.append(bd)
                    exist_depth += 1
                elif idx != 0 and data[idx-1] == '{':
                    pattern_part.append(bd)
                    exist_depth += 1
                elif idx != length -1 and data[idx+1] == '{':
                    pattern_part.append(bd)
                    exist_depth += 1
                else:
                    if exist_depth > 0:
                        pattern_part.append(bd)
                        continue
            else:
                if idx < 2: continue
                else: 
                    if idx == length-1 and data[idx-1] == '}' and exist_depth > 0:
                        pattern_part.append(bd)
                        exist_depth -= 1
                        if exist_depth != 0:
                            return False, "格式不正确", pattern_all
                        else:
                            pattern_all.append( "".join(pattern_part) )
                    elif idx != length-1 and data[idx+1] == '}' and exist_depth > 0  :
                        pattern_part.append(bd)
                        exist_depth -= 1
                        if exist_depth != 0: continue
                        else: 
                            pattern_all.append( "".join(pattern_part) )
                            pattern_part = []
                    elif idx != 0 and data[idx-1] == '}' and exist_depth > 0:
                        pattern_part.append(bd)
                        exist_depth -= 1
                        if exist_depth != 0: continue
                        else: 
                            pattern_all.append("".join(pattern_part))
                            pattern_part = []
                    else:
                        if exist_depth > 0 :
                            pattern_part.append(bd)
        if  exist_depth == 0 :                    
            return True, data, pattern_all
        else:
            return False, "填写的数据存在问题", pattern_all                    
    
    def  param_rebuild(self , params, total_info ):
        
        ins_reg = r"(\$\w+)"
        
        if type( params ) == type( u'' ) or type(params) == type(""):
            
            flag, errmsg, paths = self.filter_pattern( params )
            if flag :
                if len(paths) == 0: return True, params
                paths.sort( key=lambda x: len(x), reverse=True )
                for kk2 in paths:
                    kk2 = kk2[2:-2]
                    kk3 = kk2
                    faa = re.findall( ins_reg, kk2 )
                    if faa != []: faa.sort( key=lambda x: len(x), reverse=True )
                    for dl in faa:
                        keyword = dl[1::]
                        kk3 = kk3.replace( dl, "total_info.get(\"%s\")" % keyword )
                    params = str(params).replace("{{%s}}" %  kk2, str(eval(kk3))) 
                return True, params    
            else:
                return False, errmsg
            
        result_param = {}
        if type(params) == type([]) or params == None:
            for idx, param in enumerate(params):
                flag, deplevel = self.param_rebuild( param, total_info )
                if not flag:
                    return ( False, "返回的结果包含未定义的变量: %s" % str(params) )
                params[idx] = deplevel
            return True, params
        
        for key,value in params.items():
            
            flag, errmsg, paths = self.filter_pattern( key )
            if flag:
                if len(paths) == 0: result_param[key] = value
                paths.sort(key=lambda x: len(x), reverse=True)
                for kk2 in paths:
                    kk2 = kk2[2:-2]
                    kk3 = kk2
                    faa = re.findall( ins_reg, kk2 )
                    if faa != []: faa.sort( key=lambda x : len(x), reverse=True )
                    for dl in faa:
                        keyword = dl[1::]
                        kk3 = kk3.replace(dl, "total_info.get(\"%s\")" % keyword)
                    result_param[str(key).replace("{{%s}}" % kk2, str(eval(kk3)))] = value
            else:
                return False, errmsg
            
            
        for key,value in result_param.items():
      
            if isinstance( value, dict ) or isinstance(value, list):
                flag, reb_data = self.param_rebuild(value, total_info)
                if not flag:
                    return flag, reb_data
                else: 
                    result_param[key] = reb_data
            elif isinstance( value,str) or isinstance(value, unicode):
                flag, errmsg, paths = self.filter_pattern( value )
                if not flag: return False, errmsg
                paths.sort( key=lambda x : len(x), reverse=True )
                for vv2 in paths:
                    vv2 =  vv2[2:-2]
                    vv3 = vv2
                    fvv = re.findall( ins_reg, vv2 )
                    if fvv != []: fvv.sort( key=lambda x: len(x), reverse=True )
                    for dl in fvv:
                        keyword = dl[1::]
                        vv3 = vv3.replace(dl, "total_info.get(\"%s\")" % keyword )
                    result_param[key] = value.replace( "{{%s}}" % vv2, str(eval(vv3)) )
            else:
                continue
            
        return True, result_param                                           
        
    
dh = DataUtil()    
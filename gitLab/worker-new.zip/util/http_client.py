#-*- coding: utf-8 -*-

''' 一个模拟HTTP客户端的工具 '''

import urllib2, urllib, json, StringIO, gzip, os, cookielib, time, uuid

import  logging

def  exist_dir_unless_create(path):
    
    if os.path.exists(path): return True, "目录(%s)已经存在" % path
    else:
        try:
            os.makedirs(path, 0777)
            if os.path.exists(path): return True, "创建目录(%s)成功" % path
            else: return False, "创建目录(%s)失败" % path
        except:
            return False, "创建目录(%s)异常"  % path
    
class  HTTPClient(object):
    
    # init 中需要提供一个初始化完成的http client, 基本功能包括可以发送并接收完整的数据请求信息
    # 后续请求操作都需要使用 self.client 作为执行对象
    #  提供若干类型的cookie存储方式: M(mozilla模式的cookie支持)/A(承接上下的cookie模式)/F(不对cookie做特殊操作)
    def  __init__( self, cookie_type='F', cookie_path=None, cookie_file_name=None,  proxy="" ):
        
        self.client = None
        self.cookie_type = cookie_type
        if cookie_type == "M":
            #  检测cookie_path路径是否存在,如果不存在,尝试创建
            #  创建失败则退出, 所以在实例化该M类型的client对象时, 需要优先检测创建完成的实例是否存在client
            #  需要创建可以存储数据的目录文件
            cookie_path = cookie_path or os.path.dirname(os.path.abspath(__file__)) + "/cookie/"
            result, value = exist_dir_unless_create(cookie_path)
            if result: logging.info(value)
            else:
                logging.error(value)
                return
            cookie_file_name = cookie_file_name or ( str(time.time()) + str(uuid.uuid4()) + ".lookie" )
            cookie_full_path = cookie_path + cookie_file_name
            self.cookie_file = cookie_full_path
            self.cookieJar = cookielib.MozillaCookieJar(self.cookie_file)
            if os.path.exists(self.cookie_file):
                self.cookieJar.load(self.cookie_file, ignore_discard=True, ignore_expires=True)
            self.client = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cookieJar))
        elif  cookie_type == "A":
            #  创建执行过程中需要保存cookie的执行client
            self.cookieJar = cookielib.LWPCookieJar()
            self.client = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cookieJar))
        elif  cookie_type == "F":
            self.client = urllib2.build_opener()
        else:
            logging.error("不支持的cookie类型, 需要从M|A|F中选择适用的类型")
            self.client = None
            return
        
        proxy = proxy or ""
        if proxy != "":
            proxy_handler = urllib2.ProxyHandler({"http": proxy})
            self.client.add_handler(proxy_handler)
        
    #  以client模式发送请求, 返回结果包含是否可访问, 访问body信息/异常状态信息
    #  body_type支持三种数据处理方式,  r(raw)|j(json.dumps)|u(urlencode)|jc(中文支持)
    def   _request(self,   url,   rtype="GET",   headers=None,    body=None,    body_type="r",   timeout=20 ,  hndl='read', need_gzip=False):   
        
        if self.client == None:
            logging.error("初始化client失败, 请检查日志获取失败原因")
            return
        
        headers = headers or {}
        headers = dict({ "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36" }, **headers)
        self.client.addheaders = [(key, value) for key, value in headers.iteritems()]
        body = body  or  {}
        response = ""
        
        if rtype == "GET":
            try:
                response = getattr(self.client.open(url, timeout=timeout), hndl)()
            except  urllib2.HTTPError as e:
                return False, "url(%s)请求返回状态码异常(%s)"  %  (url, e.code)
            except urllib2.URLError:
                return  False, "提供的url(%s)无法访问, 请手工校对提供的信息是否正常" % url
        elif rtype == "POST":
            if  type(body) ==type({}) and body_type != "r":
                if  body_type == "u":
                    body = urllib.urlencode(body)
                elif  body_type == "j":
                    body = json.dumps(body)
                elif body_type=="js":
                    body = json.dumps(body, encoding="utf-8", ensure_ascii=False)
            elif type(body) == type({}) and body_type == 'r':
                return False,  "发起的post请求提供的body信息与body_type信息无法配合使用, 请校正"
            try:
                req = urllib2.Request(url=url, data=body, headers=headers)
                response = getattr( self.client.open(req), hndl)()
#                 response = getattr(self.client.open(url, body, timeout=timeout), hndl)()
            except urllib2.HTTPError as e:
                return False, "url(%s)请求返回状态码异常(%s)"  %  (url, e.code)
            except  urllib2.URLError:
                return  False, "提供的url(%s)无法访问, 请手工校对提供的信息是否正常" % url
            
        else:
            return False, "不支持的请求类型, 当前client只提供GET/POST支持"
        
        if  self.cookie_type == 'M':
            self.cookieJar.save(ignore_discard=True, ignore_expires=True)
        
        if need_gzip:
            response = self._unserialize(response)
        
        return  True, response

    #  为适配环境不稳造成的偶发性请求失败, 提供请求重试功能
    def request_with_retry(self,   url,   rtype="GET",   headers=None,    body=None,    body_type="r",   timeout=20,    retry_times = 5 ):
        flag, response = False,  ""
        for _ in  range(retry_times):
            flag, response =  self._request(url, rtype, headers, body, body_type, timeout, hndl='read',need_gzip=True)
            if flag : break
        return flag, response
    
    #  为适配环境不稳造成的偶发性请求失败, 获取连接访问完成后跳转连接
    def  request_url_with_retry(self,   url,   rtype="GET",   headers=None,    body=None,    body_type="r",   timeout=20,    retry_times = 5):
        flag, response = False,  ""
        for _ in  range(retry_times):
            flag, response =  self._request(url, rtype, headers, body, body_type, timeout, hndl='geturl')
            if flag : break
        return flag, response
    
    #  为适配环境不稳定造成的偶发性请求失败, 获取连接提供的info信息
    def  request_headers_with_retry(self, url, rtype="GET", headers=None, body=None, body_type="r", timeout=20, retry_times=5):
        flag, response = False, ""
        for _ in range(retry_times):
            flag, response = self._request(url, rtype, headers, body, body_type, timeout, hndl='info')
            response = response.headers
            if flag: break  
        return flag, response
     
    def  _unserialize(self, data):
        try:
            iostream = StringIO.StringIO(data)
            gziper = gzip.GzipFile(fileobj=iostream)
            data = gziper.read()
            return data
        except:  

            return data
    

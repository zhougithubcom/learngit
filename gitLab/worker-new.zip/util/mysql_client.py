#  -*-  coding:utf-8 -*-

import MySQLdb, decimal, datetime

#  该部分为父类, 封装fetch_all, fetch_one, update等基本操作
class XmModel(object):
    
    def  __init__(self):
        self.config = None
    
    def  _init_cursor(self):
        self.conn = MySQLdb.connect(**self.config)
        self.cursor = self.conn.cursor(MySQLdb.cursors.DictCursor)
        
    def  _drop_conn(self):
        self.cursor.close()
        self.conn.close()
        
    def  find_all(self, query, retry_times=2):
        flag, result = False, []
        for _ in range(retry_times):
            try:
                self._init_cursor()
                self.cursor.execute(query)
                result = self.cursor.fetchall()
                for  sig_result in result:
                    for key, value  in sig_result.iteritems():
                        if isinstance(value, decimal.Decimal):
                            sig_result[key] = float(value)
                        elif type(value) == type(datetime.datetime(2014,11,2,0,30,2)):
                            sig_result[key] = value.strftime("%Y-%m-%d %H:%M:%S")
                flag = True
                break
            except: continue
        return flag, result
    
    def  find_one( self, query, retry_times=2 ):
        flag, result = self.find_all(query, retry_times=retry_times)
        if len(result)==0 or flag==False: return flag, {}
        else:  return flag, result[0]
    
    def  update(self, query, retry_times=2):
        for _ in range(retry_times):
            try:
                self._init_cursor()
                self.cursor.execute(query)
                self.conn.commit()
                self.des_conn()
                return True
            except:  continue
        return False
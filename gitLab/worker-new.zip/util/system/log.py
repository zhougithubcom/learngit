# -*- coding: utf-8  -*-

import logging

def  log_init( level=logging.DEBUG,  
        format_log='%(asctime)s - %(name)s - %(levelname)s - %(message)s', filename="log/running.log"  ):
    
    logger = logging.getLogger("接口自动化")
    logger.setLevel( level )
    
    file_handler = logging.FileHandler( filename )
    file_handler.setLevel( level )
    formater = logging.Formatter( format_log )
    file_handler.setFormatter( formater )
    
    logger.addHandler( file_handler )
    return logger
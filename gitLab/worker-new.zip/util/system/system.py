# -*- coding: utf-8 -*-

import os, psutil, re

#  根据本地存储pid文件的内容判断系统中是否已经存在一个运行实例
def  get_pid( filename, logger ):
    
    if os.path.exists( filename ):
        #pid最大长度5
        pid =  open( filename ).read(5).strip()
        if  re.match('^\d+$', pid): pid = int( pid )
        else:  pid = 0
        
        try:
            pname = psutil.Process(pid).name()
            if "python" in pname.lower():
                logger.info( "系统中已经存在一个正在运行的实例, pid: %s, 为了确保运行的有效性，请手工检查该进程的具体信息" % pid )
                return False
            else:
                open( filename, "w" ).write( str(os.getpid()) )
                return True
        except psutil.NoSuchProcess:
            open( filename, "w").write( str(os.getpid()) )    
            return True
    else:
        open( filename, "a").write(str(os.getpid()) )
        return True


import socket, fcntl, struct
def  get_interface_ip( ifname ):
    s = socket.socket( socket.AF_INET, socket.SOCK_DGRAM )
    return socket.inet_ntoa( fcntl.ioctl( s.fileno(), 0x8915, struct.pack('256s', ifname[:15]))[20:24] )
def  get_machine_ip():
    ip = socket.gethostbyname( socket.gethostname() )
    if ip.startswith("127.") and os.name != "nt": 
        interfaces = ["eth0","eth1","eth2","wlan0","wlan1","wifi0","ath0","ath1","ppp0"]
        for ifname in interfaces:
            try: 
                ip = get_interface_ip(ifname)
                break
            except:
                pass
    return ip

#   判断是否有正在运行的任务
def  check_client_exist( client_pid_path ):
    if os.path.exists( client_pid_path ):
        if len( open(client_pid_path).read() ) == 0:
            return False
        else:
            pid = open( client_pid_path ).read(5)
            if re.match( '^\d+$', pid ):
                pid = int( pid )
            else:
                open( client_pid_path, "w" ).write( "" )
                return False
        try:
            pname = psutil.Process(pid).name()
            if "python" in pname.lower(): return True
        except:
            open(client_pid_path, "w").write("")
            return False
    else:
        open( client_pid_path, "a" ).write("")    
        return False


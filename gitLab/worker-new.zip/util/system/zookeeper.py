# -*- encoding: utf-8 -*-

import os, sys, traceback, time, json, logging
from  kazoo.client import KazooClient, KazooState

reload(sys)
sys.setdefaultencoding("utf-8")

logging.basicConfig()

file_path = os.path.dirname( os.path.abspath(__file__) ) + "/../../"
sys.path.append( file_path) 
from util.system.system import get_machine_ip, check_client_exist

start_file_path = file_path + "run/process_run_util.py"
stop_file_path = file_path + "run/shutdown_util.py"
debug_file_path = file_path + "run/debug.py"

def  create_node( client, nodepath, ephemeral=True):
    
    nodes = nodepath.split("/")
    
    paths = filter( lambda  b: b!='', ["/".join(nodes[0:idx]) for idx in range( len(nodes ) ) ])
    paths.append( nodepath )
    
    for idx, value in enumerate( paths ):
        if idx == len(paths) -1 :
            if client.exists( value ): client.delete( value )
            client.create(value, ephemeral=ephemeral)
        elif client.exists( value ): continue
        else: client.create( value )


class  ZookeeperHndl( object ):
    
    def  __init__(self , logger, env = "mat", timeout=15):
        self.env = env
        self.local_ip = get_machine_ip()
        self.local_znode = "/mitest/%s/control/%s" % ( self.env, self.local_ip )
        self.busy_prnode = "/mitest/%s/busy" % self.env
        self.busy_znode = "/mitest/%s/busy/%s" % ( self.env, self.local_ip )
        self.timeout = timeout
        self.logger = logger
    
    def  get_connected(self, address ):
        
        self.client = KazooClient( address )
        self.logger.info( "与zookeeper: %s建立连接" % address )
        
        try:
            self.client.start( self.timeout )
            self.logger.info( "连接成功" )
        except:
            self.logger.info( "连接失败，失败原因为: %s" % traceback.format_exc() )
            self.logger.info("5s后开始重连操作")
            time.sleep( 5 )
            self.get_connected( address )
    
    def  create_znode( self, nodepath, ephemeral=True ):
        try:
            nodes = nodepath.split( "/")
            paths = filter( lambda b: b!="", ["/".join(nodes[0:idx]) for idx in range(len(nodes))])
            paths.append( nodepath )
            for idx, value in enumerate( paths ):
                if idx == len(paths) - 1:
                    if self.client.exists(value) and ephemeral == False:
                        pass
                    else: 
                        if self.client.exists(value): self.client.delete(value)
                        self.client.create( value, ephemeral=ephemeral )
                elif self.client.exists( value ): continue
                else: self.client.create( value )
        except:
            self.logger.info( "创建节点过程出现异常, 异常信息为: %s"  % traceback.format_exc()  )
            
    def  zk_run(self , *args ):
        @self.client.DataWatch(self.local_znode)
        def  zkwatch( data, stat ):
            if data == "":
                pass
            else:
                try: data = json.loads(data)
                except: pass
                cmd = data["cmd"]
                client_pid_path = os.path.dirname( os.path.abspath(__file__) ) + "/../../config/pid/%s_client_pid.pid" % data["token"]
                if  not check_client_exist( client_pid_path ) or  cmd == "stop":
                    if self.client.exists(  self.busy_znode ):
                        try: self.client.delete( self.busy_znode )
                        except: pass
                    
                    if cmd=="start":
                        os.system("nohup python '%s'  '%s' '%s'  & "  % ( start_file_path, data["token"], self.env ))
                    elif cmd == "stop":
                        os.system( "python '%s' '%s' '%s'  "  % ( stop_file_path, data["token"], self.env  ) ) 
                    elif cmd=="debug":
                        os.system( "nohup python '%s' '%s'  '%s' &" % ( debug_file_path , data["token"], self.env ) )    
            
    
    def  zk_runner( self, address, timeout=15, name=None, method_name="run", *args ):
        
        while True:
            try:
                name = name or self.local_znode
                self.get_connected(address )
                def  my_listener(state):
                    if state != KazooState.CONNECTED:
                        time.sleep(5)
                        return self.zk_runner( address, timeout, name, method_name, *args )
                self.client.add_listener( my_listener )
                self.create_znode(name)
                self.create_znode( self.busy_prnode, False )
                self.zk_run( name, *args )
                while True:
                    time.sleep( 0.5 )
                    pass
            except KeyboardInterrupt:
                sys.exit()
                break
            except:
                self.logger.info( traceback.format_exc() )
                time.sleep( 5 )
    

# -*- encoding: utf-8 -*-

import os, sys,  platform, yaml 

file_path = os.path.dirname( os.path.abspath(__file__) ) + os.sep
sys.path.append( file_path )

config_path = os.path.dirname( os.path.abspath(__file__) ) + "/config/basic.yaml"
if  not os.path.exists( config_path ):
    print  "需要提供配置文件，路径为config/basic.yaml"
    sys.exit()

basic_data = yaml.load( open(config_path) )

#  检查关键字段值是否存在
for x in ["logger", "pid", "zookeeper", "timeout", "env_list"]:
    if x not in basic_data.keys():
        print  "缺失必要字段信息: %s" % x
        sys.exit()
        
#  初始化日志信息
from util.system import log
logger = log.log_init( filename=basic_data["logger"] )

if platform.system() != "Linux":
    logger.info( "由于windows/mac系统的进程id无法进行控制，暂不提供工具支持" )
else:
    logger.info("运行环境符合要求，开始解析配置信息")

from util.system.system import get_pid
exist = get_pid(  basic_data["pid"] , logger)

if  exist:
    running_env = "mat"
    if len( sys.argv ) > 1:
        if sys.argv[1] not in basic_data["env_list"]: 
            logger.error( "启动参数申请访问的环境不存在，当前支持的系统包括: ", "|".join(basic_data["env_list"]) )
            sys.exit()
        running_env = sys.argv[1]
        
    from util.system.zookeeper import  ZookeeperHndl
    zh =  ZookeeperHndl( logger, env=running_env, timeout=int( basic_data["timeout"] ) )      
    zh.zk_runner( basic_data["zookeeper"], basic_data["timeout"] )
        